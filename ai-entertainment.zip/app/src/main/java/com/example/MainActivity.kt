package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.EntertainmentViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.AppBottomNavBar
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MyListScreen
import com.example.ui.screens.PremiumScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.StoryDetailScreen
import com.example.data.admob.AdMobManager
import com.example.ui.screens.VideoPlayerScreen
import com.example.ui.theme.CanvasObsidian
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: EntertainmentViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Google AdMob & preload ads
        AdMobManager.initialize(this)
        AdMobManager.loadInterstitialAd(this)
        AdMobManager.loadRewardedAd(this)

        setContent {
            MyApplicationTheme {
                EntertainmentAppRoot(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun EntertainmentAppRoot(viewModel: EntertainmentViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    // Handle system back press
    BackHandler(enabled = currentScreen != ScreenDestination.HOME) {
        viewModel.navigateBack()
    }

    // Screens where bottom navigation bar is visible
    val showBottomBar = when (currentScreen) {
        ScreenDestination.HOME,
        ScreenDestination.SEARCH,
        ScreenDestination.CATEGORIES,
        ScreenDestination.MY_LIST,
        ScreenDestination.PROFILE -> true
        else -> false // Hidden on Video Player, Story Details, Premium, Admin, Auth
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasObsidian),
        containerColor = CanvasObsidian,
        bottomBar = {
            if (showBottomBar) {
                AppBottomNavBar(
                    currentScreen = currentScreen,
                    onNavigate = { destination ->
                        viewModel.navigateTo(destination)
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                ScreenDestination.HOME -> HomeScreen(viewModel = viewModel)
                ScreenDestination.SEARCH -> SearchScreen(viewModel = viewModel)
                ScreenDestination.CATEGORIES -> CategoriesScreen(viewModel = viewModel)
                ScreenDestination.MY_LIST -> MyListScreen(viewModel = viewModel)
                ScreenDestination.PROFILE -> ProfileScreen(viewModel = viewModel)
                ScreenDestination.STORY_DETAIL -> StoryDetailScreen(viewModel = viewModel)
                ScreenDestination.VIDEO_PLAYER -> VideoPlayerScreen(viewModel = viewModel)
                ScreenDestination.PREMIUM_PAYMENT -> PremiumScreen(viewModel = viewModel)
                ScreenDestination.ADMIN_DASHBOARD -> AdminDashboardScreen(viewModel = viewModel)
                ScreenDestination.AUTH -> AuthScreen(viewModel = viewModel)
            }
        }
    }
}
