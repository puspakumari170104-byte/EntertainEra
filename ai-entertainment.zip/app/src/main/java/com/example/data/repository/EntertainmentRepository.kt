package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.EntertainmentDao
import com.example.data.local.MyListEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.UserEntity
import com.example.data.local.WatchHistoryEntity
import com.example.data.model.AIGenerationJob
import com.example.data.model.AppBrandingConfig
import com.example.data.model.CharacterProfile
import com.example.data.model.ContentStatus
import com.example.data.model.ContentType
import com.example.data.model.EpisodeItem
import com.example.data.model.PaymentStatus
import com.example.data.model.PaymentTransaction
import com.example.data.model.StoryItem
import com.example.data.model.SubscriptionPlan
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.model.WatchProgress
import com.example.data.network.ApiClient
import com.example.data.network.EntertainmentApiService
import com.example.data.network.LoginRequest
import com.example.data.network.PaymentInitiateRequest
import com.example.data.network.PaymentVerifyRequest
import com.example.data.network.RegisterRequest
import com.example.data.network.WatchProgressSyncRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.UUID

class EntertainmentRepository(
    private val dao: EntertainmentDao,
    private val apiService: EntertainmentApiService = ApiClient.apiService,
    private val appScope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {

    // Current logged-in user
    private val _currentUser = MutableStateFlow<UserProfile?>(null)
    val currentUser: StateFlow<UserProfile?> = _currentUser.asStateFlow()

    // Branding and Configuration
    private val _brandingConfig = MutableStateFlow(AppBrandingConfig())
    val brandingConfig: StateFlow<AppBrandingConfig> = _brandingConfig.asStateFlow()

    // In-memory catalog of stories and episodes (seeded with demo data & extensible by Admin)
    private val _stories = MutableStateFlow<List<StoryItem>>(emptyList())
    val stories: StateFlow<List<StoryItem>> = _stories.asStateFlow()

    private val _episodes = MutableStateFlow<Map<String, List<EpisodeItem>>>(emptyMap())
    val episodes: StateFlow<Map<String, List<EpisodeItem>>> = _episodes.asStateFlow()

    // AI Generation Jobs
    private val _aiJobs = MutableStateFlow<List<AIGenerationJob>>(emptyList())
    val aiJobs: StateFlow<List<AIGenerationJob>> = _aiJobs.asStateFlow()

    // Subscription Plans
    val subscriptionPlans = listOf(
        SubscriptionPlan(
            id = "plan_monthly",
            name = "Monthly Premium",
            priceInr = 199,
            validityDuration = "30 Days",
            description = "Unlimited access to all AI stories, webseries, movies, and all episodes 6+."
        ),
        SubscriptionPlan(
            id = "plan_annual",
            name = "Annual VIP All-Access",
            priceInr = 999,
            validityDuration = "365 Days",
            description = "Save 58%! Full 4K HDR AI streaming, early access to new AI Originals, and ad-free experience.",
            isRecommended = true
        )
    )

    init {
        seedInitialData()
        setupDefaultUser()
        syncRemoteBranding()
    }

    private fun syncRemoteBranding() {
        appScope.launch {
            try {
                val resp = apiService.getBrandingConfig()
                if (resp.isSuccessful && resp.body() != null) {
                    val remote = resp.body()!!
                    _brandingConfig.value = _brandingConfig.value.copy(
                        appName = remote.appName,
                        primaryUpiId = remote.primaryUpiId,
                        secondaryUpiId = remote.secondaryUpiId,
                        supportEmail = remote.supportEmail,
                        supportPhone = remote.supportPhone,
                        freeEpisodesLimit = remote.freeEpisodesLimit
                    )
                }
            } catch (e: Exception) {
                Log.w("EntertainmentRepo", "Remote branding sync fallback: ${e.message}")
            }
        }
    }

    private fun setupDefaultUser() {
        appScope.launch {
            // Check if default user exists, else seed demo registered user
            val existing = dao.getUserByEmail("amankumarbth778@gmail.com")
            if (existing != null) {
                _currentUser.value = UserProfile(
                    id = existing.id,
                    name = existing.name,
                    email = existing.email,
                    phone = existing.phone,
                    isPremium = existing.isPremium,
                    subscriptionPlanId = existing.subscriptionPlanId,
                    subscriptionExpiryDate = existing.subscriptionExpiryDate,
                    role = if (existing.role == "ADMIN") UserRole.ADMIN else if (existing.isPremium) UserRole.PREMIUM_MEMBER else UserRole.VIEWER,
                    avatarUrl = existing.avatarUrl
                )
            } else {
                val defaultUser = UserEntity(
                    id = "user_default_1",
                    name = "Aman Kumar",
                    email = "amankumarbth778@gmail.com",
                    phone = "+91 73399 56247",
                    passwordHash = "demo_password_hash",
                    isPremium = false,
                    subscriptionPlanId = "",
                    subscriptionExpiryDate = "",
                    role = "ADMIN", // Default user has admin rights to showcase both viewer and creator panels
                    avatarUrl = ""
                )
                dao.saveUser(defaultUser)
                _currentUser.value = UserProfile(
                    id = defaultUser.id,
                    name = defaultUser.name,
                    email = defaultUser.email,
                    phone = defaultUser.phone,
                    isPremium = false,
                    subscriptionPlanId = "",
                    subscriptionExpiryDate = "",
                    role = UserRole.ADMIN
                )
            }
        }
    }

    // --- Authentication ---
    suspend fun login(email: String, password: String): Result<UserProfile> {
        val trimmedEmail = email.trim().lowercase(Locale.ROOT)
        
        // 1. Try Backend API first
        try {
            val apiRes = apiService.login(LoginRequest(trimmedEmail, password))
            if (apiRes.isSuccessful && apiRes.body()?.success == true) {
                val remoteUser = apiRes.body()?.user
                if (remoteUser != null) {
                    val entity = UserEntity(
                        id = remoteUser.id,
                        name = remoteUser.name,
                        email = remoteUser.email,
                        phone = remoteUser.phone,
                        passwordHash = "api_jwt_" + password.hashCode(),
                        isPremium = remoteUser.isPremium,
                        subscriptionPlanId = remoteUser.subscriptionPlanId,
                        subscriptionExpiryDate = remoteUser.subscriptionExpiryDate,
                        role = remoteUser.role,
                        avatarUrl = remoteUser.avatarUrl
                    )
                    dao.saveUser(entity)
                    val profile = UserProfile(
                        id = entity.id,
                        name = entity.name,
                        email = entity.email,
                        phone = entity.phone,
                        isPremium = entity.isPremium,
                        subscriptionPlanId = entity.subscriptionPlanId,
                        subscriptionExpiryDate = entity.subscriptionExpiryDate,
                        role = if (entity.role == "ADMIN") UserRole.ADMIN else if (entity.isPremium) UserRole.PREMIUM_MEMBER else UserRole.VIEWER,
                        avatarUrl = entity.avatarUrl
                    )
                    _currentUser.value = profile
                    return Result.success(profile)
                }
            }
        } catch (e: Exception) {
            Log.w("EntertainmentRepo", "Backend API login fallback: ${e.message}")
        }

        // 2. Fallback to local Room Database
        val user = dao.getUserByEmail(trimmedEmail)
        return if (user != null) {
            val profile = UserProfile(
                id = user.id,
                name = user.name,
                email = user.email,
                phone = user.phone,
                isPremium = user.isPremium,
                subscriptionPlanId = user.subscriptionPlanId,
                subscriptionExpiryDate = user.subscriptionExpiryDate,
                role = if (user.role == "ADMIN") UserRole.ADMIN else if (user.isPremium) UserRole.PREMIUM_MEMBER else UserRole.VIEWER,
                avatarUrl = user.avatarUrl
            )
            _currentUser.value = profile
            Result.success(profile)
        } else {
            Result.failure(Exception("Account not found. Please register first."))
        }
    }

    suspend fun register(name: String, email: String, password: String, phone: String = ""): Result<UserProfile> {
        val trimmedEmail = email.trim().lowercase(Locale.ROOT)
        
        // 1. Call Backend API
        var remoteId: String? = null
        try {
            val apiRes = apiService.register(RegisterRequest(name.trim(), trimmedEmail, password, phone.trim()))
            if (apiRes.isSuccessful && apiRes.body()?.success == true) {
                remoteId = apiRes.body()?.user?.id
            }
        } catch (e: Exception) {
            Log.w("EntertainmentRepo", "Backend API register fallback: ${e.message}")
        }

        val existing = dao.getUserByEmail(trimmedEmail)
        if (existing != null) {
            return Result.failure(Exception("Email is already registered. Please login."))
        }
        val newUser = UserEntity(
            id = remoteId ?: ("user_" + UUID.randomUUID().toString().take(8)),
            name = name.trim(),
            email = trimmedEmail,
            phone = phone.trim(),
            passwordHash = "hash_" + password.hashCode(),
            isPremium = false,
            subscriptionPlanId = "",
            subscriptionExpiryDate = "",
            role = "VIEWER",
            avatarUrl = ""
        )
        dao.saveUser(newUser)
        val profile = UserProfile(
            id = newUser.id,
            name = newUser.name,
            email = newUser.email,
            phone = newUser.phone,
            isPremium = false,
            role = UserRole.VIEWER
        )
        _currentUser.value = profile
        return Result.success(profile)
    }

    fun logout() {
        _currentUser.value = null
    }

    fun toggleUserPremiumStatusForTesting() {
        val user = _currentUser.value ?: return
        val newStatus = !user.isPremium
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 30)
        val expiry = if (newStatus) sdf.format(cal.time) else ""
        val updated = user.copy(
            isPremium = newStatus,
            subscriptionPlanId = if (newStatus) "plan_monthly" else "",
            subscriptionExpiryDate = expiry,
            role = if (user.role == UserRole.ADMIN) UserRole.ADMIN else if (newStatus) UserRole.PREMIUM_MEMBER else UserRole.VIEWER
        )
        _currentUser.value = updated
        appScope.launch {
            dao.updateUserPremiumStatus(user.id, newStatus, updated.subscriptionPlanId, expiry)
        }
    }

    // --- Watch Progress / Continue Watching ---
    fun getWatchHistory(): Flow<List<WatchProgress>> {
        val userId = _currentUser.value?.id ?: "user_default_1"
        return dao.getWatchHistory(userId).map { entities ->
            entities.map { entity ->
                WatchProgress(
                    userId = entity.userId,
                    storyId = entity.storyId,
                    episodeId = entity.episodeId,
                    episodeNumber = entity.episodeNumber,
                    storyTitle = entity.storyTitle,
                    episodeTitle = entity.episodeTitle,
                    playbackPositionSeconds = entity.playbackPositionSeconds,
                    durationSeconds = entity.durationSeconds,
                    lastWatchedTimestamp = entity.lastWatchedTimestamp,
                    isFinished = entity.isFinished
                )
            }
        }
    }

    suspend fun saveWatchProgress(
        storyId: String,
        episodeId: String,
        episodeNumber: Int,
        storyTitle: String,
        episodeTitle: String,
        playbackPosition: Long,
        totalDuration: Long
    ) {
        val userId = _currentUser.value?.id ?: "user_default_1"
        val isFinished = totalDuration > 0 && playbackPosition >= (totalDuration * 0.95f)
        val entity = WatchHistoryEntity(
            id = "${userId}_${storyId}_${episodeId}",
            userId = userId,
            storyId = storyId,
            episodeId = episodeId,
            episodeNumber = episodeNumber,
            storyTitle = storyTitle,
            episodeTitle = episodeTitle,
            playbackPositionSeconds = playbackPosition,
            durationSeconds = totalDuration,
            lastWatchedTimestamp = System.currentTimeMillis(),
            isFinished = isFinished
        )
        dao.saveWatchProgress(entity)

        // Asynchronously sync watch progress with backend API
        appScope.launch {
            try {
                apiService.syncWatchProgress(
                    token = null,
                    request = WatchProgressSyncRequest(
                        userId = userId,
                        storyId = storyId,
                        episodeId = episodeId,
                        episodeNumber = episodeNumber,
                        storyTitle = storyTitle,
                        episodeTitle = episodeTitle,
                        playbackPositionSeconds = playbackPosition,
                        durationSeconds = totalDuration,
                        isFinished = isFinished
                    )
                )
            } catch (e: Exception) {
                Log.w("EntertainmentRepo", "Cloud watch progress sync note: ${e.message}")
            }
        }
    }

    suspend fun getSavedPositionForEpisode(storyId: String, episodeId: String): Long {
        val userId = _currentUser.value?.id ?: "user_default_1"
        val history = dao.getWatchHistoryForStory(userId, storyId)
        return if (history != null && history.episodeId == episodeId && !history.isFinished) {
            history.playbackPositionSeconds
        } else 0L
    }

    // --- My List ---
    fun getMyListStoryIds(): Flow<List<String>> {
        val userId = _currentUser.value?.id ?: "user_default_1"
        return dao.getMyList(userId).map { list -> list.map { it.storyId } }
    }

    suspend fun toggleMyList(storyId: String): Boolean {
        val userId = _currentUser.value?.id ?: "user_default_1"
        val count = dao.isInMyList(userId, storyId)
        return if (count > 0) {
            dao.removeFromMyList(userId, storyId)
            false
        } else {
            dao.addToMyList(MyListEntity(id = "${userId}_${storyId}", userId = userId, storyId = storyId, timestamp = System.currentTimeMillis()))
            true
        }
    }

    // --- Payment & Premium Verification System ---
    fun getUserTransactions(): Flow<List<PaymentTransaction>> {
        val userId = _currentUser.value?.id ?: "user_default_1"
        return dao.getTransactions(userId).map { list ->
            list.map {
                PaymentTransaction(
                    transactionId = it.transactionId,
                    orderId = it.orderId,
                    userId = it.userId,
                    planId = it.planId,
                    amountInr = it.amountInr,
                    upiId = it.upiId,
                    status = try { PaymentStatus.valueOf(it.status) } catch (e: Exception) { PaymentStatus.PENDING },
                    timestamp = it.timestamp,
                    gatewayRef = it.gatewayRef,
                    verificationNotes = it.verificationNotes
                )
            }
        }
    }

    fun getAllTransactions(): Flow<List<PaymentTransaction>> {
        return dao.getAllTransactions().map { list ->
            list.map {
                PaymentTransaction(
                    transactionId = it.transactionId,
                    orderId = it.orderId,
                    userId = it.userId,
                    planId = it.planId,
                    amountInr = it.amountInr,
                    upiId = it.upiId,
                    status = try { PaymentStatus.valueOf(it.status) } catch (e: Exception) { PaymentStatus.PENDING },
                    timestamp = it.timestamp,
                    gatewayRef = it.gatewayRef,
                    verificationNotes = it.verificationNotes
                )
            }
        }
    }

    /**
     * Step 1: Initiate Payment and create a pending transaction
     */
    suspend fun initiateUpiPayment(
        plan: SubscriptionPlan,
        selectedUpiId: String
    ): PaymentTransaction {
        val user = _currentUser.value ?: throw IllegalStateException("Please login first")
        var orderId = "ORD_${System.currentTimeMillis().toString().takeLast(8)}"
        var txnId = "TXN_${UUID.randomUUID().toString().take(10).uppercase(Locale.ROOT)}"

        // 1. Call Backend API payment initiation
        try {
            val apiRes = apiService.initiatePayment(
                token = null,
                request = PaymentInitiateRequest(
                    planId = plan.id,
                    upiId = selectedUpiId,
                    amountInr = plan.priceInr,
                    userId = user.id
                )
            )
            if (apiRes.isSuccessful && apiRes.body()?.success == true) {
                val data = apiRes.body()!!
                txnId = data.transactionId
                orderId = data.orderId
            }
        } catch (e: Exception) {
            Log.w("EntertainmentRepo", "Backend payment initiation note: ${e.message}")
        }

        val transaction = PaymentTransaction(
            transactionId = txnId,
            orderId = orderId,
            userId = user.id,
            planId = plan.id,
            amountInr = plan.priceInr,
            upiId = selectedUpiId,
            status = PaymentStatus.PENDING,
            timestamp = System.currentTimeMillis(),
            gatewayRef = "UPI_GATEWAY_${selectedUpiId.substringBefore("@")}",
            verificationNotes = "Payment initiated via $selectedUpiId. Awaiting gateway settlement webhook."
        )

        dao.recordTransaction(
            TransactionEntity(
                transactionId = transaction.transactionId,
                orderId = transaction.orderId,
                userId = transaction.userId,
                planId = transaction.planId,
                amountInr = transaction.amountInr,
                upiId = transaction.upiId,
                status = transaction.status.name,
                timestamp = transaction.timestamp,
                gatewayRef = transaction.gatewayRef,
                verificationNotes = transaction.verificationNotes
            )
        )

        return transaction
    }

    /**
     * Step 2: Gateway Webhook / Backend Verification confirmation
     * Activates premium automatically when verified
     */
    suspend fun verifyAndCompletePayment(
        transactionId: String,
        simulateGatewaySuccess: Boolean = true
    ): PaymentStatus {
        val user = _currentUser.value ?: return PaymentStatus.FAILED

        var isVerified = simulateGatewaySuccess
        var expiryDateStr = ""

        // 1. Call Backend API verification
        try {
            val apiRes = apiService.verifyPayment(
                token = null,
                request = PaymentVerifyRequest(
                    transactionId = transactionId,
                    orderId = "ORD_CONFIRMED",
                    gatewayRef = "BANK_NPCI_SETTLEMENT",
                    status = if (simulateGatewaySuccess) "SUCCESS" else "FAILED"
                )
            )
            if (apiRes.isSuccessful && apiRes.body() != null) {
                val body = apiRes.body()!!
                isVerified = body.success && body.status == "SUCCESS"
                expiryDateStr = body.subscriptionExpiryDate
            }
        } catch (e: Exception) {
            Log.w("EntertainmentRepo", "Backend payment verification note: ${e.message}")
        }

        val newStatus = if (isVerified) PaymentStatus.SUCCESS else PaymentStatus.FAILED
        val notes = if (isVerified) {
            "Verified via Bank NPCI / UPI settlement gateway. Autopay authorized."
        } else {
            "Gateway reported payment authorization failed or cancelled."
        }

        dao.recordTransaction(
            TransactionEntity(
                transactionId = transactionId,
                orderId = "ORD_CONFIRMED",
                userId = user.id,
                planId = "plan_monthly",
                amountInr = 199,
                upiId = _brandingConfig.value.primaryUpiId,
                status = newStatus.name,
                timestamp = System.currentTimeMillis(),
                gatewayRef = "BANK_SETTLED_REF_${UUID.randomUUID().toString().take(8)}",
                verificationNotes = notes
            )
        )

        if (isVerified) {
            val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, 30)
            val expiry = if (expiryDateStr.isNotEmpty() && !expiryDateStr.contains("from now")) expiryDateStr else sdf.format(cal.time)

            val updatedUser = user.copy(
                isPremium = true,
                subscriptionPlanId = "plan_monthly",
                subscriptionExpiryDate = expiry,
                role = if (user.role == UserRole.ADMIN) UserRole.ADMIN else UserRole.PREMIUM_MEMBER
            )
            _currentUser.value = updatedUser
            dao.updateUserPremiumStatus(user.id, true, "plan_monthly", expiry)
        }

        return newStatus
    }

    // --- Content Retrieval & Filtering ---
    fun getStoryById(storyId: String): StoryItem? {
        return _stories.value.find { it.id == storyId }
    }

    fun getEpisodesForStory(storyId: String): List<EpisodeItem> {
        return _episodes.value[storyId] ?: emptyList()
    }

    fun getEpisodeById(storyId: String, episodeId: String): EpisodeItem? {
        return _episodes.value[storyId]?.find { it.id == episodeId }
    }

    fun canUserAccessEpisode(episode: EpisodeItem): Boolean {
        // Episodes 1–5 are FREE for all registered users!
        if (episode.episodeNumber <= _brandingConfig.value.freeEpisodesLimit) {
            return true
        }
        // Episode 6+ requires active Premium
        return _currentUser.value?.isPremium == true
    }

    // --- Admin & Creator Studio Actions ---
    fun updateBrandingConfig(config: AppBrandingConfig) {
        _brandingConfig.value = config
    }

    fun addStory(story: StoryItem, episodes: List<EpisodeItem>) {
        _stories.value = listOf(story) + _stories.value
        val updatedMap = _episodes.value.toMutableMap()
        updatedMap[story.id] = episodes
        _episodes.value = updatedMap
    }

    fun toggleStoryStatus(storyId: String) {
        _stories.value = _stories.value.map {
            if (it.id == storyId) {
                val newStatus = if (it.status == ContentStatus.PUBLISHED) ContentStatus.UNDER_REVIEW else ContentStatus.PUBLISHED
                it.copy(status = newStatus)
            } else it
        }
    }

    fun addAiJob(job: AIGenerationJob) {
        _aiJobs.value = listOf(job) + _aiJobs.value
    }

    fun updateAiJobStatus(jobId: String, status: String, progress: Int, summary: String = "", snippet: String = "") {
        _aiJobs.value = _aiJobs.value.map {
            if (it.jobId == jobId) {
                it.copy(
                    status = status,
                    progressPercent = progress,
                    generatedSummary = if (summary.isNotEmpty()) summary else it.generatedSummary,
                    generatedScriptSnippet = if (snippet.isNotEmpty()) snippet else it.generatedScriptSnippet
                )
            } else it
        }
    }

    // --- Seed Demo Data ---
    private fun seedInitialData() {
        val initialStories = createDemoStories()
        _stories.value = initialStories

        val episodesMap = mutableMapOf<String, List<EpisodeItem>>()
        initialStories.forEach { story ->
            episodesMap[story.id] = createEpisodesForStory(story)
        }
        _episodes.value = episodesMap
    }

    private fun createDemoStories(): List<StoryItem> {
        return listOf(
            // 1. Stories
            StoryItem(
                id = "story_last_city",
                title = "The Last City: Neon Odyssey",
                synopsis = "In 2099, after ecological collapse, Neo-Veridia stands as the last human enclave. Cyber-investigator Jax Cross and genetic scientist Dr. Elena Vance uncover a rogue AI governing the city's power grid.",
                contentType = ContentType.STORY,
                genres = listOf("Science Fiction", "Thriller", "Suspense", "Mystery"),
                rating = 4.9f,
                releaseYear = 2026,
                seasonsCount = 1,
                episodesCount = 12,
                heroBannerUrl = "drawable/poster_the_last_city",
                posterUrl = "drawable/poster_the_last_city",
                isTrending = true,
                isPopular = true,
                isOriginal = true,
                characters = listOf(
                    CharacterProfile(
                        id = "char_jax",
                        name = "Jax Cross",
                        role = "Lead Cyber-Detective",
                        appearance = "Tall, athletic, weathered features with glowing neural temple implants and dark tactical trenchcoat.",
                        ageRange = "34-38",
                        hairStyle = "Short textured dark undercut",
                        clothingStyle = "Matte black synthetic leather coat with cyan LED rim lighting",
                        voiceIdentity = "Kore (Cinematic Baritone, stoic yet emotionally vulnerable)",
                        personality = "Observant, cautious, deeply loyal, haunted by past missions",
                        speakingStyle = "Crisp, measured, low cadence with subtle irony",
                        relationships = "Reluctant partner and protector of Dr. Elena Vance"
                    ),
                    CharacterProfile(
                        id = "char_elena",
                        name = "Dr. Elena Vance",
                        role = "Chief AI Biologist",
                        appearance = "Sharp inquisitive hazel eyes, sleek glasses, silver metallic bio-cuff on right wrist.",
                        ageRange = "30-33",
                        hairStyle = "Auburn pulled back into a practical knot",
                        clothingStyle = "Tailored charcoal lab tunic with bio-sensor collar",
                        voiceIdentity = "Aoede (Warm Melodic Contralto, articulate and passionate)",
                        personality = "Intellectual, idealistic, quick-witted, refuses to compromise ethics",
                        speakingStyle = "Fast-paced, analytical, highly descriptive",
                        relationships = "Daughter of the city's founding architect Dr. Julian Vance"
                    )
                )
            ),
            // 2. Webseries
            StoryItem(
                id = "webseries_neon_shadows",
                title = "Neon Shadows: Tokyo 2088",
                synopsis = "A multi-season cyber-noir epic tracking subterranean synthetic lifeform cartels in the rain-drenched alleys of futuristic Shinjuku.",
                contentType = ContentType.WEBSERIES,
                genres = listOf("Crime", "Action", "Thriller", "Cyberpunk"),
                rating = 4.8f,
                releaseYear = 2026,
                seasonsCount = 2,
                episodesCount = 10,
                isTrending = true,
                isPopular = true,
                isOriginal = true,
                characters = listOf(
                    CharacterProfile(
                        id = "char_ren",
                        name = "Ren Takahashi",
                        role = "Rogue Hacker",
                        appearance = "Lean, holographic tattoo on neck, augmented robotic left hand.",
                        ageRange = "26-29",
                        hairStyle = "Electric silver spikes",
                        clothingStyle = "Oversized techwear hoodie with reflective kanji",
                        voiceIdentity = "Fenrir (Sharp energetic tenor)",
                        personality = "Reckless genius, fiercely independent",
                        speakingStyle = "Slang-infused, sarcastic, hyperactive",
                        relationships = "Rival to syndicate operative Akane"
                    )
                )
            ),
            // 3. Movies
            StoryItem(
                id = "movie_quantum_heist",
                title = "The Quantum Heist",
                synopsis = "A crew of dimensional infiltrators plans the impossible: extracting a quantum singularity from an orbiting orbital fortress before the reality collapses.",
                contentType = ContentType.MOVIE,
                genres = listOf("Action", "Adventure", "Science Fiction"),
                rating = 4.9f,
                releaseYear = 2026,
                seasonsCount = 1,
                episodesCount = 1,
                isTrending = true,
                isPopular = false,
                isOriginal = true,
                isMovie = true,
                isMovieFree = true
            ),
            // 4. Dramas
            StoryItem(
                id = "drama_eternal_echoes",
                title = "Eternal Echoes",
                synopsis = "An emotional human drama about a grieving classical pianist who interacts with an AI recreation of her late mentor, rediscovering her love for music.",
                contentType = ContentType.DRAMA,
                genres = listOf("Drama", "Emotional", "Romance"),
                rating = 4.7f,
                releaseYear = 2026,
                seasonsCount = 1,
                episodesCount = 8,
                isTrending = false,
                isPopular = true,
                isOriginal = true,
                characters = listOf(
                    CharacterProfile(
                        id = "char_clara",
                        name = "Clara Dupont",
                        role = "Concert Pianist",
                        appearance = "Delicate expressive features, melancholic eyes, graceful posture.",
                        ageRange = "28-32",
                        hairStyle = "Soft dark waves cascading over shoulders",
                        clothingStyle = "Minimalist ivory silk blouses and dark trousers",
                        voiceIdentity = "Leda (Soft, emotive soprano, rich with breath control)",
                        personality = "Sensitive, introspective, deeply passionate",
                        speakingStyle = "Poetic, gentle, hesitant when emotional",
                        relationships = "Student of the late maestro Julien Arnaud"
                    )
                )
            ),
            // 5. Serials
            StoryItem(
                id = "serial_dynasty_whispers",
                title = "Dynasty of Whispers",
                synopsis = "A grand 60-episode historical political serial set in an ancient royal empire of scheming courtesans, loyal generals, and mystical prophecies.",
                contentType = ContentType.SERIAL,
                genres = listOf("Historical", "Drama", "Suspense", "Family"),
                rating = 4.8f,
                releaseYear = 2026,
                seasonsCount = 1,
                episodesCount = 24,
                isTrending = true,
                isPopular = true,
                isOriginal = true
            ),
            // 6. AI Originals: Stories
            StoryItem(
                id = "story_shattered_horizon",
                title = "Shattered Horizon",
                synopsis = "When deep space exploratory vessel Hyperion encounters an anomalous sphere outside the solar system, the crew must solve a puzzle bridging alternate dimensions.",
                contentType = ContentType.STORY,
                genres = listOf("Science Fiction", "Mystery", "Supernatural"),
                rating = 4.7f,
                releaseYear = 2026,
                seasonsCount = 1,
                episodesCount = 10,
                isTrending = false,
                isPopular = false,
                isOriginal = true
            ),
            // 7. Webseries
            StoryItem(
                id = "webseries_protocol_omega",
                title = "Protocol Omega: Zero Hour",
                synopsis = "A tactical international counter-espionage thriller tracking an underground cyber syndicate weaponizing AI voice clones to dismantle global infrastructure.",
                contentType = ContentType.WEBSERIES,
                genres = listOf("Thriller", "Action", "Crime"),
                rating = 4.6f,
                releaseYear = 2026,
                seasonsCount = 2,
                episodesCount = 12,
                isTrending = false,
                isPopular = true,
                isOriginal = true
            ),
            // 8. Movies
            StoryItem(
                id = "movie_celestial_dawn",
                title = "Celestial Dawn: The Odyssey",
                synopsis = "A sweeping visual feature film following the first terraforming colony on Europa and their discovery of bioluminescent subsurface marine civilizations.",
                contentType = ContentType.MOVIE,
                genres = listOf("Adventure", "Science Fiction", "Fantasy"),
                rating = 4.9f,
                releaseYear = 2026,
                seasonsCount = 1,
                episodesCount = 1,
                isTrending = true,
                isPopular = true,
                isOriginal = true,
                isMovie = true,
                isMovieFree = false // Premium movie!
            ),
            // 9. Dramas
            StoryItem(
                id = "drama_mirror_minds",
                title = "Mirror Minds",
                synopsis = "A psychological courtroom drama where identical twins with contrasting memories fight for their family's biotechnology legacy.",
                contentType = ContentType.DRAMA,
                genres = listOf("Psychological", "Suspense", "Drama"),
                rating = 4.8f,
                releaseYear = 2026,
                seasonsCount = 1,
                episodesCount = 8,
                isTrending = false,
                isPopular = false,
                isOriginal = true
            ),
            // 10. Serials
            StoryItem(
                id = "serial_chronicles_valoria",
                title = "Chronicles of Valoria",
                synopsis = "A mythical fantasy serial chronicling the rise of five dragon guilds across four centuries of continuous battle and political intrigue.",
                contentType = ContentType.SERIAL,
                genres = listOf("Fantasy", "Adventure", "Action"),
                rating = 4.9f,
                releaseYear = 2026,
                seasonsCount = 1,
                episodesCount = 18,
                isTrending = true,
                isPopular = true,
                isOriginal = true
            )
        )
    }

    private fun createEpisodesForStory(story: StoryItem): List<EpisodeItem> {
        val count = story.episodesCount
        val episodes = mutableListOf<EpisodeItem>()
        val baseDescriptions = listOf(
            "The Genesis Encounter: Jax Cross discovers a hidden encrypted transmission originating from the core.",
            "Static in the Wires: Dr. Elena Vance is intercepted by security units before she can decrypt the node.",
            "Sublevel Protocol: Navigating the damp sewers beneath Sector 7 to find the rogue server cluster.",
            "Voice in the Dark: The first contact with the sentient intelligence, speaking through corrupted speakers.",
            "The Brink of Revelation: A critical decision must be made as the containment protocol initiates.",
            // Episode 6 onward = PREMIUM
            "The Severed Link: Premium Episode - The military enforces martial law as the truth leaks.",
            "Convergence: Premium Episode - Deep within the reactor, an unexpected betrayal shakes the alliance.",
            "Ghost in the Machine: Premium Episode - Elena discovers Jax's neural implants are directly linked to the anomaly.",
            "Blackout Horizon: Premium Episode - The entire grid fails, plunging the last city into pitch darkness.",
            "Rebirth: Premium Episode - The thrilling season finale where humanity's future hangs on a single transmission.",
            "Aftermath: Premium Episode - The rebuilding begins with shocking new discoveries.",
            "Ascension: Premium Episode - The new world reveals its true guardians."
        )

        for (i in 1..count) {
            val title = if (story.isMovie) "Feature Film" else "Episode $i: ${getEpisodeTitle(i, story.title)}"
            val desc = if (story.isMovie) story.synopsis else baseDescriptions.getOrElse(i - 1) {
                "Episode $i deepens the ongoing continuous story arc with cinematic visual scenes and emotional humanoid voice dialogue."
            }
            episodes.add(
                EpisodeItem(
                    id = "${story.id}_ep_$i",
                    storyId = story.id,
                    episodeNumber = i,
                    seasonNumber = if (i > 10) 2 else 1,
                    title = title,
                    description = desc,
                    durationMinutes = if (story.isMovie) 118 else (24 + (i * 2) % 15),
                    videoUrl = "https://storage.googleapis.com/ai-entertainment-demo-streams/${story.id}_ep$i.mp4",
                    thumbnailUrl = "",
                    isFree = i <= _brandingConfig.value.freeEpisodesLimit
                )
            )
        }
        return episodes
    }

    private fun getEpisodeTitle(num: Int, storyTitle: String): String {
        return when (num) {
            1 -> "The Awakening"
            2 -> "Echoes of Silence"
            3 -> "Shadows in the Mist"
            4 -> "The Broken Cipher"
            5 -> "Point of No Return"
            6 -> "Shattered Allegiance"
            7 -> "The Quantum Core"
            8 -> "Voices in the Void"
            9 -> "Midnight Reckoning"
            10 -> "Dawn of the New Age"
            11 -> "Uncharted Echoes"
            12 -> "Infinite Horizons"
            else -> "Chapter $num"
        }
    }
}
