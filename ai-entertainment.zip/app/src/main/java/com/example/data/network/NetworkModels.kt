package com.example.data.network

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class LoginRequest(
    val email: String,
    val password: String
)

@JsonClass(generateAdapter = true)
data class RegisterRequest(
    val name: String,
    val email: String,
    val password: String,
    val phone: String = ""
)

@JsonClass(generateAdapter = true)
data class RemoteUserDto(
    val id: String,
    val name: String,
    val email: String,
    val phone: String = "",
    @Json(name = "is_premium") val isPremium: Boolean = false,
    @Json(name = "subscription_plan_id") val subscriptionPlanId: String = "",
    @Json(name = "subscription_expiry_date") val subscriptionExpiryDate: String = "",
    val role: String = "VIEWER",
    @Json(name = "avatar_url") val avatarUrl: String = ""
)

@JsonClass(generateAdapter = true)
data class AuthResponse(
    val success: Boolean,
    val message: String = "",
    val token: String? = null,
    val user: RemoteUserDto? = null
)

@JsonClass(generateAdapter = true)
data class StoryDto(
    val id: String,
    val title: String,
    val synopsis: String,
    @Json(name = "content_type") val contentType: String,
    val genres: List<String> = emptyList(),
    val rating: Float = 4.8f,
    @Json(name = "release_year") val releaseYear: Int = 2026,
    @Json(name = "seasons_count") val seasonsCount: Int = 1,
    @Json(name = "episodes_count") val episodesCount: Int = 12,
    @Json(name = "poster_url") val posterUrl: String = "",
    @Json(name = "hero_banner_url") val heroBannerUrl: String = "",
    @Json(name = "is_trending") val isTrending: Boolean = false,
    @Json(name = "is_popular") val isPopular: Boolean = false,
    @Json(name = "is_original") val isOriginal: Boolean = true,
    @Json(name = "is_movie") val isMovie: Boolean = false,
    @Json(name = "is_movie_free") val isMovieFree: Boolean = true
)

@JsonClass(generateAdapter = true)
data class StoriesResponse(
    val success: Boolean,
    val total: Int = 0,
    val stories: List<StoryDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class EpisodeDto(
    val id: String,
    @Json(name = "story_id") val storyId: String,
    @Json(name = "episode_number") val episodeNumber: Int,
    @Json(name = "season_number") val seasonNumber: Int = 1,
    val title: String,
    val description: String,
    @Json(name = "duration_minutes") val durationMinutes: Int = 24,
    @Json(name = "video_url") val videoUrl: String,
    @Json(name = "thumbnail_url") val thumbnailUrl: String = "",
    @Json(name = "is_free") val isFree: Boolean = true
)

@JsonClass(generateAdapter = true)
data class EpisodesResponse(
    val success: Boolean,
    @Json(name = "story_id") val storyId: String,
    val episodes: List<EpisodeDto> = emptyList()
)

@JsonClass(generateAdapter = true)
data class PaymentInitiateRequest(
    @Json(name = "plan_id") val planId: String,
    @Json(name = "upi_id") val upiId: String,
    @Json(name = "amount_inr") val amountInr: Int,
    @Json(name = "user_id") val userId: String
)

@JsonClass(generateAdapter = true)
data class PaymentInitiateResponse(
    val success: Boolean,
    @Json(name = "transaction_id") val transactionId: String,
    @Json(name = "order_id") val orderId: String,
    @Json(name = "amount_inr") val amountInr: Int,
    @Json(name = "upi_id") val upiId: String,
    val message: String = ""
)

@JsonClass(generateAdapter = true)
data class PaymentVerifyRequest(
    @Json(name = "transaction_id") val transactionId: String,
    @Json(name = "order_id") val orderId: String,
    @Json(name = "gateway_ref") val gatewayRef: String,
    val status: String
)

@JsonClass(generateAdapter = true)
data class PaymentVerifyResponse(
    val success: Boolean,
    @Json(name = "transaction_id") val transactionId: String,
    val status: String,
    @Json(name = "is_premium") val isPremium: Boolean,
    @Json(name = "subscription_expiry_date") val subscriptionExpiryDate: String,
    val message: String = ""
)

@JsonClass(generateAdapter = true)
data class WatchProgressSyncRequest(
    @Json(name = "user_id") val userId: String,
    @Json(name = "story_id") val storyId: String,
    @Json(name = "episode_id") val episodeId: String,
    @Json(name = "episode_number") val episodeNumber: Int,
    @Json(name = "story_title") val storyTitle: String,
    @Json(name = "episode_title") val episodeTitle: String,
    @Json(name = "playback_position_seconds") val playbackPositionSeconds: Long,
    @Json(name = "duration_seconds") val durationSeconds: Long,
    @Json(name = "is_finished") val isFinished: Boolean
)

@JsonClass(generateAdapter = true)
data class WatchProgressSyncResponse(
    val success: Boolean,
    val message: String = ""
)

@JsonClass(generateAdapter = true)
data class RemoteBrandingResponse(
    @Json(name = "app_name") val appName: String = "AI Entertainment",
    @Json(name = "primary_upi_id") val primaryUpiId: String = "amankumarbth778@okaxis",
    @Json(name = "secondary_upi_id") val secondaryUpiId: String = "7339956247@paytm",
    @Json(name = "support_email") val supportEmail: String = "amankumarbth778@gmail.com",
    @Json(name = "support_phone") val supportPhone: String = "+91 73399 56247",
    @Json(name = "free_episodes_limit") val freeEpisodesLimit: Int = 5,
    @Json(name = "announcement_banner") val announcementBanner: String = "Welcome to AI Entertainment! Episodes 1-5 are 100% Free."
)

@JsonClass(generateAdapter = true)
data class AIGenerationApiRequest(
    val prompt: String,
    val genre: String,
    val style: String,
    @Json(name = "character_count") val characterCount: Int = 2,
    @Json(name = "target_episodes") val targetEpisodes: Int = 10
)

@JsonClass(generateAdapter = true)
data class AIGenerationApiResponse(
    val success: Boolean,
    @Json(name = "job_id") val jobId: String,
    val status: String,
    val message: String = ""
)
