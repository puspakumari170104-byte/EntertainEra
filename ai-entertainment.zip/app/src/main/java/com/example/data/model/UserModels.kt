package com.example.data.model

enum class UserRole {
    VIEWER,
    PREMIUM_MEMBER,
    ADMIN
}

data class UserProfile(
    val id: String,
    val name: String,
    val email: String,
    val phone: String = "",
    val isPremium: Boolean = false,
    val subscriptionPlanId: String = "",
    val subscriptionExpiryDate: String = "",
    val role: UserRole = UserRole.VIEWER,
    val avatarUrl: String = ""
)

enum class PaymentStatus {
    PENDING,
    SUCCESS,
    FAILED,
    CANCELLED,
    REFUNDED
}

data class SubscriptionPlan(
    val id: String,
    val name: String,
    val priceInr: Int,
    val validityDuration: String,
    val description: String,
    val isRecommended: Boolean = false
)

data class PaymentTransaction(
    val transactionId: String,
    val orderId: String,
    val userId: String,
    val planId: String,
    val amountInr: Int,
    val upiId: String,
    val status: PaymentStatus,
    val timestamp: Long = System.currentTimeMillis(),
    val gatewayRef: String = "",
    val verificationNotes: String = ""
)

data class WatchProgress(
    val userId: String,
    val storyId: String,
    val episodeId: String,
    val episodeNumber: Int,
    val storyTitle: String,
    val episodeTitle: String,
    val playbackPositionSeconds: Long,
    val durationSeconds: Long,
    val lastWatchedTimestamp: Long = System.currentTimeMillis(),
    val isFinished: Boolean = false
) {
    val progressPercentage: Float
        get() = if (durationSeconds > 0) {
            (playbackPositionSeconds.toFloat() / durationSeconds.toFloat()).coerceIn(0f, 1f)
        } else 0f
}

data class MyListItem(
    val userId: String,
    val storyId: String,
    val addedTimestamp: Long = System.currentTimeMillis()
)

data class AIGenerationJob(
    val jobId: String,
    val title: String,
    val prompt: String,
    val contentType: ContentType,
    val genre: String,
    val episodeCount: Int,
    val targetAudience: String,
    val tone: String,
    val language: String,
    val status: String, // QUEUED, PROCESSING, COMPLETED, FAILED
    val progressPercent: Int = 0,
    val generatedSummary: String = "",
    val generatedScriptSnippet: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class AppBrandingConfig(
    val appName: String = "AI Entertainment",
    val primaryUpiId: String = "7339956247@ybl",
    val secondaryUpiId: String = "7339956247@ptyes",
    val freeEpisodesLimit: Int = 5,
    val monthlyPriceInr: Int = 199,
    val annualPriceInr: Int = 999,
    val currency: String = "INR",
    val isAdSupported: Boolean = false,
    val supportEmail: String = "support@aientertainment.com",
    val supportPhone: String = "+91 73399 56247"
)
