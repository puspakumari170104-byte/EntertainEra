package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface EntertainmentDao {

    // --- Watch History ---
    @Query("SELECT * FROM watch_history WHERE userId = :userId ORDER BY lastWatchedTimestamp DESC")
    fun getWatchHistory(userId: String): Flow<List<WatchHistoryEntity>>

    @Query("SELECT * FROM watch_history WHERE userId = :userId AND storyId = :storyId LIMIT 1")
    suspend fun getWatchHistoryForStory(userId: String, storyId: String): WatchHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveWatchProgress(entity: WatchHistoryEntity)

    // --- My List ---
    @Query("SELECT * FROM my_list WHERE userId = :userId ORDER BY timestamp DESC")
    fun getMyList(userId: String): Flow<List<MyListEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addToMyList(item: MyListEntity)

    @Query("DELETE FROM my_list WHERE userId = :userId AND storyId = :storyId")
    suspend fun removeFromMyList(userId: String, storyId: String)

    @Query("SELECT COUNT(*) FROM my_list WHERE userId = :userId AND storyId = :storyId")
    suspend fun isInMyList(userId: String, storyId: String): Int

    // --- Transactions ---
    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY timestamp DESC")
    fun getTransactions(userId: String): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun recordTransaction(transaction: TransactionEntity)

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    // --- Users ---
    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY name ASC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveUser(user: UserEntity)

    @Query("UPDATE users SET isPremium = :isPremium, subscriptionPlanId = :planId, subscriptionExpiryDate = :expiry WHERE id = :userId")
    suspend fun updateUserPremiumStatus(userId: String, isPremium: Boolean, planId: String, expiry: String)
}
