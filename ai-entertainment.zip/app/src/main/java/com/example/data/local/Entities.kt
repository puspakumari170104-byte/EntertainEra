package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val id: String, // userId_storyId_episodeId
    val userId: String,
    val storyId: String,
    val episodeId: String,
    val episodeNumber: Int,
    val storyTitle: String,
    val episodeTitle: String,
    val playbackPositionSeconds: Long,
    val durationSeconds: Long,
    val lastWatchedTimestamp: Long,
    val isFinished: Boolean
)

@Entity(tableName = "my_list")
data class MyListEntity(
    @PrimaryKey val id: String, // userId_storyId
    val userId: String,
    val storyId: String,
    val timestamp: Long
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val transactionId: String,
    val orderId: String,
    val userId: String,
    val planId: String,
    val amountInr: Int,
    val upiId: String,
    val status: String,
    val timestamp: Long,
    val gatewayRef: String,
    val verificationNotes: String
)

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val phone: String,
    val passwordHash: String,
    val isPremium: Boolean,
    val subscriptionPlanId: String,
    val subscriptionExpiryDate: String,
    val role: String,
    val avatarUrl: String
)
