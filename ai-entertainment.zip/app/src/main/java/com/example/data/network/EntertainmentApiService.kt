package com.example.data.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface EntertainmentApiService {

    @GET("api/v1/config/branding")
    suspend fun getBrandingConfig(): Response<RemoteBrandingResponse>

    @GET("api/v1/content/stories")
    suspend fun getStories(
        @Query("category") category: String? = null,
        @Query("limit") limit: Int = 30
    ): Response<StoriesResponse>

    @GET("api/v1/content/stories/{storyId}/episodes")
    suspend fun getEpisodes(
        @Path("storyId") storyId: String
    ): Response<EpisodesResponse>

    @POST("api/v1/auth/login")
    suspend fun login(
        @Body request: LoginRequest
    ): Response<AuthResponse>

    @POST("api/v1/auth/register")
    suspend fun register(
        @Body request: RegisterRequest
    ): Response<AuthResponse>

    @POST("api/v1/payments/initiate")
    suspend fun initiatePayment(
        @Header("Authorization") token: String?,
        @Body request: PaymentInitiateRequest
    ): Response<PaymentInitiateResponse>

    @POST("api/v1/payments/verify")
    suspend fun verifyPayment(
        @Header("Authorization") token: String?,
        @Body request: PaymentVerifyRequest
    ): Response<PaymentVerifyResponse>

    @POST("api/v1/user/watch-progress")
    suspend fun syncWatchProgress(
        @Header("Authorization") token: String?,
        @Body request: WatchProgressSyncRequest
    ): Response<WatchProgressSyncResponse>

    @POST("api/v1/ai/generate-story")
    suspend fun triggerAIGeneration(
        @Header("Authorization") token: String?,
        @Body request: AIGenerationApiRequest
    ): Response<AIGenerationApiResponse>
}
