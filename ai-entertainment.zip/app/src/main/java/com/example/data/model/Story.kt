package com.example.data.model

data class CharacterProfile(
    val id: String,
    val name: String,
    val role: String,
    val appearance: String,
    val ageRange: String,
    val hairStyle: String,
    val clothingStyle: String,
    val voiceIdentity: String, // e.g. "Kore - Emotional Baritone", "Aoede - Melodic Soprano"
    val personality: String,
    val speakingStyle: String,
    val relationships: String
)

enum class ContentType {
    STORY,
    WEBSERIES,
    MOVIE,
    DRAMA,
    SERIAL
}

enum class ContentStatus {
    DRAFT,
    AI_GENERATED,
    UNDER_REVIEW,
    APPROVED,
    PUBLISHED,
    ARCHIVED
}

data class EpisodeItem(
    val id: String,
    val storyId: String,
    val episodeNumber: Int,
    val seasonNumber: Int = 1,
    val title: String,
    val description: String,
    val durationMinutes: Int,
    val videoUrl: String,
    val thumbnailUrl: String = "",
    val subtitlesAvailable: List<String> = listOf("English", "Hindi", "Spanish"),
    val audioTracksAvailable: List<String> = listOf("AI Humanoid Voice (English)", "AI Humanoid Voice (Hindi)"),
    val releaseDate: String = "2026-08",
    val isFree: Boolean = episodeNumber <= 5 // Episodes 1–5 free, 6+ premium
)

data class StoryItem(
    val id: String,
    val title: String,
    val synopsis: String,
    val contentType: ContentType,
    val genres: List<String>,
    val rating: Float = 4.8f,
    val releaseYear: Int = 2026,
    val seasonsCount: Int = 1,
    val episodesCount: Int,
    val heroBannerUrl: String = "",
    val posterUrl: String = "",
    val characters: List<CharacterProfile> = emptyList(),
    val isAiGenerated: Boolean = true,
    val aiModelInfo: String = "Generated with Cinematic AI Video & Humanoid Voice Pipeline",
    val status: ContentStatus = ContentStatus.PUBLISHED,
    val isTrending: Boolean = false,
    val isPopular: Boolean = false,
    val isOriginal: Boolean = true,
    val isMovie: Boolean = contentType == ContentType.MOVIE,
    val isMovieFree: Boolean = true // For movies specifically
)
