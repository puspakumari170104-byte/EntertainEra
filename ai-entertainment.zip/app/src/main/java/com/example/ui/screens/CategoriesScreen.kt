package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Subscriptions
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ContentType
import com.example.ui.EntertainmentViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.StoryCard
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.AccentViolet
import com.example.ui.theme.CanvasObsidian
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceMidnight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class CategoryMeta(
    val title: String,
    val icon: ImageVector,
    val filterType: ContentType? = null,
    val isOriginal: Boolean = false,
    val isTrending: Boolean = false,
    val isPremiumOnly: Boolean = false
)

@Composable
fun CategoriesScreen(
    viewModel: EntertainmentViewModel,
    modifier: Modifier = Modifier
) {
    val allStories by viewModel.allStories.collectAsState()

    val categories = listOf(
        CategoryMeta("All Content", Icons.Default.Category),
        CategoryMeta("Stories", Icons.Default.LiveTv, filterType = ContentType.STORY),
        CategoryMeta("Webseries", Icons.Default.Subscriptions, filterType = ContentType.WEBSERIES),
        CategoryMeta("Movies", Icons.Default.Movie, filterType = ContentType.MOVIE),
        CategoryMeta("Dramas", Icons.Default.Psychology, filterType = ContentType.DRAMA),
        CategoryMeta("Serials", Icons.Default.Tv, filterType = ContentType.SERIAL),
        CategoryMeta("AI Originals", Icons.Default.AutoAwesome, isOriginal = true),
        CategoryMeta("Trending", Icons.Default.TrendingUp, isTrending = true),
        CategoryMeta("VIP Premium", Icons.Default.WorkspacePremium, isPremiumOnly = true)
    )

    var selectedIndex by remember { mutableIntStateOf(0) }
    val currentMeta = categories[selectedIndex]

    val filteredStories = allStories.filter { story ->
        when {
            currentMeta.filterType != null -> story.contentType == currentMeta.filterType
            currentMeta.isOriginal -> story.isOriginal
            currentMeta.isTrending -> story.isTrending
            currentMeta.isPremiumOnly -> story.episodesCount > 5 || !story.isMovieFree
            else -> true
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CanvasObsidian)
            .testTag("categories_screen")
    ) {
        // --- Header ---
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(
                text = "Explore Categories",
                color = TextPrimary,
                fontSize = 22.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = "Browse by entertainment format and AI genre",
                color = TextMuted,
                fontSize = 12.sp
            )
        }

        // --- Category Tabs ---
        ScrollableTabRow(
            selectedTabIndex = selectedIndex,
            containerColor = SurfaceMidnight,
            contentColor = TextPrimary,
            edgePadding = 16.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
                    color = AccentViolet
                )
            }
        ) {
            categories.forEachIndexed { index, meta ->
                val isSelected = selectedIndex == index
                Tab(
                    selected = isSelected,
                    onClick = { selectedIndex = index },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = meta.icon,
                                contentDescription = null,
                                tint = if (isSelected) AccentViolet else TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = meta.title,
                                color = if (isSelected) TextPrimary else TextSecondary,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    }
                )
            }
        }

        // --- Category Summary Bar ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${currentMeta.title} (${filteredStories.size} titles)",
                color = AccentCyan,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )

            if (currentMeta.isPremiumOnly) {
                Text(
                    text = "Ep 6+ Premium",
                    color = AccentGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // --- Content Grid ---
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 130.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredStories) { story ->
                StoryCard(
                    story = story,
                    onClick = { viewModel.selectStory(story) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
