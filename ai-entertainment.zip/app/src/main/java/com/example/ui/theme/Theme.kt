package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val OTTDarkColorScheme = darkColorScheme(
    primary = AccentViolet,
    onPrimary = TextPrimary,
    primaryContainer = AccentVioletDark,
    onPrimaryContainer = TextPrimary,
    secondary = AccentCyan,
    onSecondary = CanvasObsidian,
    tertiary = AccentGold,
    onTertiary = CanvasObsidian,
    background = CanvasObsidian,
    onBackground = TextPrimary,
    surface = SurfaceMidnight,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    error = AccentCrimson,
    onError = TextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to cinematic dark for OTT streaming
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = OTTDarkColorScheme,
        typography = Typography,
        content = content
    )
}
