package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic OTT Entertainment Dark Palette
val CanvasObsidian = Color(0xFF090B10)
val SurfaceMidnight = Color(0xFF121622)
val SurfaceCard = Color(0xFF1B2132)
val SurfaceCardElevated = Color(0xFF242C42)
val BorderSubtle = Color(0xFF2E3852)

// Vibrant OTT Accents
val AccentViolet = Color(0xFF8C52FF)
val AccentVioletDark = Color(0xFF5E27CD)
val AccentCyan = Color(0xFF00E5FF)
val AccentGold = Color(0xFFFFB800)
val AccentGoldGlow = Color(0xFFFFD700)
val AccentCrimson = Color(0xFFFF3366)
val AccentGreen = Color(0xFF10B981)

// Typography & Neutrals
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val OverlayGradientStart = Color(0x00090B10)
val OverlayGradientEnd = Color(0xFF090B10)

// Free & Premium Badges
val BadgeFreeGreen = Color(0xFF059669)
val BadgePremiumGold = Color(0xFFD97706)
