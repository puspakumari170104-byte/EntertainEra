package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.GeminiStoryEngine
import com.example.data.ai.GeneratedStoryProductionPlan
import com.example.data.ai.StoryGenerationInput
import com.example.data.local.AppDatabase
import com.example.data.model.AppBrandingConfig
import com.example.data.model.CharacterProfile
import com.example.data.model.ContentStatus
import com.example.data.model.ContentType
import com.example.data.model.EpisodeItem
import com.example.data.model.PaymentStatus
import com.example.data.model.PaymentTransaction
import com.example.data.model.StoryItem
import com.example.data.model.SubscriptionPlan
import com.example.data.model.UserProfile
import com.example.data.model.UserRole
import com.example.data.model.WatchProgress
import com.example.data.repository.EntertainmentRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class ScreenDestination {
    HOME,
    SEARCH,
    CATEGORIES,
    MY_LIST,
    PROFILE,
    STORY_DETAIL,
    VIDEO_PLAYER,
    PREMIUM_PAYMENT,
    ADMIN_DASHBOARD,
    AUTH
}

data class PaymentUiState(
    val selectedPlan: SubscriptionPlan? = null,
    val selectedUpiId: String = "7339956247@ybl",
    val activeTransaction: PaymentTransaction? = null,
    val isInitiating: Boolean = false,
    val isVerifying: Boolean = false,
    val verificationMessage: String = "",
    val status: PaymentStatus? = null,
    val error: String? = null
)

class EntertainmentViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = EntertainmentRepository(database.entertainmentDao())
    private val storyEngine = GeminiStoryEngine()

    // Navigation State
    private val _currentScreen = MutableStateFlow(ScreenDestination.HOME)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    private val _navigationStack = mutableListOf<ScreenDestination>()

    // Current User
    val currentUser: StateFlow<UserProfile?> = repository.currentUser

    // Branding Config
    val brandingConfig: StateFlow<AppBrandingConfig> = repository.brandingConfig

    // Story Catalog
    val allStories: StateFlow<List<StoryItem>> = repository.stories

    // Watch Progress
    val watchHistory: StateFlow<List<WatchProgress>> = repository.getWatchHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // My List
    val myListStoryIds: StateFlow<List<String>> = repository.getMyListStoryIds()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected Story and Episodes
    private val _selectedStory = MutableStateFlow<StoryItem?>(null)
    val selectedStory: StateFlow<StoryItem?> = _selectedStory.asStateFlow()

    private val _selectedStoryEpisodes = MutableStateFlow<List<EpisodeItem>>(emptyList())
    val selectedStoryEpisodes: StateFlow<List<EpisodeItem>> = _selectedStoryEpisodes.asStateFlow()

    // Active Playback State
    private val _playingStory = MutableStateFlow<StoryItem?>(null)
    val playingStory: StateFlow<StoryItem?> = _playingStory.asStateFlow()

    private val _playingEpisode = MutableStateFlow<EpisodeItem?>(null)
    val playingEpisode: StateFlow<EpisodeItem?> = _playingEpisode.asStateFlow()

    private val _savedPlaybackPosition = MutableStateFlow(0L)
    val savedPlaybackPosition: StateFlow<Long> = _savedPlaybackPosition.asStateFlow()

    // Category / Filter selection
    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedGenre = MutableStateFlow<String?>(null)
    val selectedGenre: StateFlow<String?> = _selectedGenre.asStateFlow()

    // Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchResults: StateFlow<List<StoryItem>> = combine(
        allStories,
        _searchQuery,
        _selectedGenre
    ) { stories, query, genre ->
        stories.filter { story ->
            val matchesQuery = query.isBlank() ||
                story.title.contains(query, ignoreCase = true) ||
                story.synopsis.contains(query, ignoreCase = true) ||
                story.genres.any { it.contains(query, ignoreCase = true) } ||
                story.characters.any { it.name.contains(query, ignoreCase = true) }

            val matchesGenre = genre == null || story.genres.contains(genre)
            matchesQuery && matchesGenre
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Payment State
    private val _paymentState = MutableStateFlow(
        PaymentUiState(
            selectedPlan = repository.subscriptionPlans.firstOrNull(),
            selectedUpiId = repository.brandingConfig.value.primaryUpiId
        )
    )
    val paymentState: StateFlow<PaymentUiState> = _paymentState.asStateFlow()

    val userTransactions: StateFlow<List<PaymentTransaction>> = repository.getUserTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions: StateFlow<List<PaymentTransaction>> = repository.getAllTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val subscriptionPlans = repository.subscriptionPlans

    // AI Generation in Admin
    private val _isGeneratingAiStory = MutableStateFlow(false)
    val isGeneratingAiStory: StateFlow<Boolean> = _isGeneratingAiStory.asStateFlow()

    private val _lastGeneratedPlan = MutableStateFlow<GeneratedStoryProductionPlan?>(null)
    val lastGeneratedPlan: StateFlow<GeneratedStoryProductionPlan?> = _lastGeneratedPlan.asStateFlow()

    // --- Navigation Methods ---
    fun navigateTo(destination: ScreenDestination) {
        if (_currentScreen.value != destination) {
            _navigationStack.add(_currentScreen.value)
            _currentScreen.value = destination
        }
    }

    fun navigateBack(): Boolean {
        if (_navigationStack.isNotEmpty()) {
            _currentScreen.value = _navigationStack.removeAt(_navigationStack.lastIndex)
            return true
        } else if (_currentScreen.value != ScreenDestination.HOME) {
            _currentScreen.value = ScreenDestination.HOME
            return true
        }
        return false
    }

    // --- Story & Episode Selection ---
    fun selectStory(story: StoryItem) {
        _selectedStory.value = story
        val episodes = repository.getEpisodesForStory(story.id)
        _selectedStoryEpisodes.value = episodes
        navigateTo(ScreenDestination.STORY_DETAIL)
    }

    fun playEpisode(story: StoryItem, episode: EpisodeItem) {
        val canAccess = repository.canUserAccessEpisode(episode)
        if (!canAccess) {
            // Episode 6+ and user is not premium: Show Premium Subscription Screen!
            _paymentState.value = _paymentState.value.copy(
                selectedPlan = repository.subscriptionPlans.firstOrNull(),
                status = null,
                error = null,
                isVerifying = false
            )
            navigateTo(ScreenDestination.PREMIUM_PAYMENT)
            return
        }

        viewModelScope.launch {
            val savedPos = repository.getSavedPositionForEpisode(story.id, episode.id)
            _savedPlaybackPosition.value = savedPos
            _playingStory.value = story
            _playingEpisode.value = episode
            navigateTo(ScreenDestination.VIDEO_PLAYER)
        }
    }

    fun onEpisodePlaybackProgress(positionSeconds: Long, totalDurationSeconds: Long) {
        val story = _playingStory.value ?: return
        val episode = _playingEpisode.value ?: return
        viewModelScope.launch {
            repository.saveWatchProgress(
                storyId = story.id,
                episodeId = episode.id,
                episodeNumber = episode.episodeNumber,
                storyTitle = story.title,
                episodeTitle = episode.title,
                playbackPosition = positionSeconds,
                totalDuration = totalDurationSeconds
            )
        }
    }

    fun playNextEpisode(): Boolean {
        val story = _playingStory.value ?: return false
        val currentEp = _playingEpisode.value ?: return false
        val episodes = repository.getEpisodesForStory(story.id)
        val nextIndex = episodes.indexOfFirst { it.id == currentEp.id } + 1

        if (nextIndex in episodes.indices) {
            val nextEp = episodes[nextIndex]
            val canAccess = repository.canUserAccessEpisode(nextEp)
            if (canAccess) {
                _playingEpisode.value = nextEp
                _savedPlaybackPosition.value = 0L
                return true
            } else {
                // Next episode is premium locked! Redirect to premium screen
                _paymentState.value = _paymentState.value.copy(
                    status = null,
                    error = null,
                    isVerifying = false
                )
                navigateTo(ScreenDestination.PREMIUM_PAYMENT)
                return false
            }
        }
        return false
    }

    // --- My List ---
    fun toggleMyList(storyId: String) {
        viewModelScope.launch {
            repository.toggleMyList(storyId)
        }
    }

    // --- Search & Filter ---
    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun onGenreSelected(genre: String?) {
        _selectedGenre.value = if (_selectedGenre.value == genre) null else genre
    }

    fun onCategorySelected(category: String) {
        _selectedCategory.value = category
    }

    // --- Payment Flow ---
    fun selectPaymentPlan(plan: SubscriptionPlan) {
        _paymentState.value = _paymentState.value.copy(selectedPlan = plan)
    }

    fun selectUpiId(upiId: String) {
        _paymentState.value = _paymentState.value.copy(selectedUpiId = upiId)
    }

    fun initiatePayment() {
        val plan = _paymentState.value.selectedPlan ?: return
        val upiId = _paymentState.value.selectedUpiId

        viewModelScope.launch {
            _paymentState.value = _paymentState.value.copy(
                isInitiating = true,
                error = null
            )
            try {
                val txn = repository.initiateUpiPayment(plan, upiId)
                _paymentState.value = _paymentState.value.copy(
                    isInitiating = false,
                    activeTransaction = txn,
                    status = PaymentStatus.PENDING,
                    verificationMessage = "Payment initiated with $upiId. Order ID: ${txn.orderId}. Awaiting gateway webhook..."
                )
            } catch (e: Exception) {
                _paymentState.value = _paymentState.value.copy(
                    isInitiating = false,
                    error = e.message ?: "Failed to initiate payment"
                )
            }
        }
    }

    fun verifyTransaction(simulateSuccess: Boolean = true) {
        val txn = _paymentState.value.activeTransaction ?: return
        viewModelScope.launch {
            _paymentState.value = _paymentState.value.copy(
                isVerifying = true,
                verificationMessage = "Contacting payment gateway NPCI verification server..."
            )
            delay(1800) // Realistic gateway webhook verification latency

            val resultStatus = repository.verifyAndCompletePayment(txn.transactionId, simulateSuccess)
            _paymentState.value = _paymentState.value.copy(
                isVerifying = false,
                status = resultStatus,
                verificationMessage = if (resultStatus == PaymentStatus.SUCCESS) {
                    "Payment verified successfully! Premium Membership activated."
                } else {
                    "Payment authorization failed or pending. Please try again or check your UPI app."
                }
            )

            // If success and we were looking at a locked episode, user can now play it!
            if (resultStatus == PaymentStatus.SUCCESS && _selectedStory.value != null) {
                // User is now premium
            }
        }
    }

    fun toggleTestPremium() {
        repository.toggleUserPremiumStatusForTesting()
    }

    // --- Authentication ---
    fun login(email: String, pass: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = repository.login(email, pass)
            if (res.isSuccess) {
                onResult(true, "Welcome back, ${res.getOrNull()?.name}!")
                navigateBack()
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Login failed")
            }
        }
    }

    fun register(name: String, email: String, pass: String, phone: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val res = repository.register(name, email, pass, phone)
            if (res.isSuccess) {
                onResult(true, "Account created successfully!")
                navigateBack()
            } else {
                onResult(false, res.exceptionOrNull()?.message ?: "Registration failed")
            }
        }
    }

    fun logout() {
        repository.logout()
        navigateTo(ScreenDestination.HOME)
    }

    // --- AI Story Generator (Admin) ---
    fun generateAiStory(input: StoryGenerationInput) {
        viewModelScope.launch {
            _isGeneratingAiStory.value = true
            try {
                val plan = storyEngine.generateStoryPlan(input)
                _lastGeneratedPlan.value = plan

                // Auto-create as an AI generated draft in repository
                val newStoryId = "ai_story_${UUID.randomUUID().toString().take(6)}"
                val newStory = StoryItem(
                    id = newStoryId,
                    title = input.titleIdea.ifBlank { "Untitled AI Saga" },
                    synopsis = plan.logline.ifBlank { plan.storyConcept },
                    contentType = input.contentType,
                    genres = listOf(input.genre, "AI Original"),
                    rating = 4.9f,
                    releaseYear = 2026,
                    seasonsCount = 1,
                    episodesCount = plan.episodeBreakdowns.size,
                    characters = plan.characters,
                    isAiGenerated = true,
                    aiModelInfo = "Gemini 3.5 Flash Narrative Engine & Humanoid TTS",
                    status = ContentStatus.AI_GENERATED,
                    isOriginal = true
                )

                val episodes = plan.episodeBreakdowns.map { ep ->
                    EpisodeItem(
                        id = "${newStoryId}_ep_${ep.episodeNumber}",
                        storyId = newStoryId,
                        episodeNumber = ep.episodeNumber,
                        title = ep.title,
                        description = ep.summary,
                        durationMinutes = input.episodeDurationMinutes,
                        videoUrl = "https://storage.googleapis.com/ai-entertainment-demo-streams/${newStoryId}_ep${ep.episodeNumber}.mp4",
                        isFree = ep.episodeNumber <= brandingConfig.value.freeEpisodesLimit
                    )
                }

                repository.addStory(newStory, episodes)
            } finally {
                _isGeneratingAiStory.value = false
            }
        }
    }

    fun publishStory(storyId: String) {
        repository.toggleStoryStatus(storyId)
    }

    fun updateBranding(config: AppBrandingConfig) {
        repository.updateBrandingConfig(config)
    }
}
