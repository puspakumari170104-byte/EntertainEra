package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.admob.AdMobBanner
import com.example.data.model.ContentType
import com.example.data.model.StoryItem
import com.example.data.model.WatchProgress
import com.example.ui.EntertainmentViewModel
import com.example.ui.ScreenDestination
import com.example.ui.components.CategoryFilterRow
import com.example.ui.components.StoryCard
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.AccentViolet
import com.example.ui.theme.CanvasObsidian
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceMidnight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    viewModel: EntertainmentViewModel,
    modifier: Modifier = Modifier
) {
    val stories by viewModel.allStories.collectAsState()
    val watchHistory by viewModel.watchHistory.collectAsState()
    val myListIds by viewModel.myListStoryIds.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val branding by viewModel.brandingConfig.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()

    // Primary categories requested in section 3
    val primaryCategories = listOf(
        "All",
        "Stories",
        "Webseries",
        "Movies",
        "Dramas",
        "Serials",
        "AI Originals",
        "Trending",
        "New Releases",
        "Popular",
        "Continue Watching",
        "My List",
        "Premium"
    )

    val heroStory = stories.firstOrNull { it.id == "story_last_city" } ?: stories.firstOrNull()

    // Filtered lists for rows
    val trending = stories.filter { it.isTrending }
    val popular = stories.filter { it.isPopular }
    val originals = stories.filter { it.isOriginal }
    val webseries = stories.filter { it.contentType == ContentType.WEBSERIES }
    val movies = stories.filter { it.contentType == ContentType.MOVIE }
    val dramas = stories.filter { it.contentType == ContentType.DRAMA }
    val serials = stories.filter { it.contentType == ContentType.SERIAL }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CanvasObsidian)
            .testTag("home_screen_lazy_column")
    ) {
        // --- Top Bar ---
        item {
            HomeTopBar(
                appName = branding.appName,
                isPremium = currentUser?.isPremium == true,
                onSearchClick = { viewModel.navigateTo(ScreenDestination.SEARCH) },
                onProfileClick = { viewModel.navigateTo(ScreenDestination.PROFILE) },
                onAdminClick = { viewModel.navigateTo(ScreenDestination.ADMIN_DASHBOARD) },
                onPremiumClick = { viewModel.navigateTo(ScreenDestination.PREMIUM_PAYMENT) }
            )
        }

        // --- Category Filters ---
        item {
            CategoryFilterRow(
                categories = primaryCategories,
                selectedCategory = selectedCategory,
                onSelect = { cat ->
                    viewModel.onCategorySelected(cat)
                    when (cat) {
                        "Categories" -> viewModel.navigateTo(ScreenDestination.CATEGORIES)
                        "My List" -> viewModel.navigateTo(ScreenDestination.MY_LIST)
                        "Search" -> viewModel.navigateTo(ScreenDestination.SEARCH)
                        "Premium" -> viewModel.navigateTo(ScreenDestination.PREMIUM_PAYMENT)
                    }
                },
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        // --- Cinematic Hero Banner ---
        if (heroStory != null && selectedCategory == "All") {
            item {
                HeroBanner(
                    story = heroStory,
                    isInMyList = myListIds.contains(heroStory.id),
                    onWatchClick = { viewModel.selectStory(heroStory) },
                    onToggleMyList = { viewModel.toggleMyList(heroStory.id) }
                )
            }
        }

        // --- AdMob Sponsored Banner (Free Users Only, Ad-Free for VIP) ---
        item {
            AdMobBanner(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                isPremiumUser = currentUser?.isPremium == true
            )
        }

        // --- Continue Watching Row (if any) ---
        if (watchHistory.isNotEmpty() && (selectedCategory == "All" || selectedCategory == "Continue Watching")) {
            item {
                ContinueWatchingSection(
                    historyList = watchHistory,
                    onItemClick = { progress ->
                        val story = stories.find { it.id == progress.storyId }
                        if (story != null) {
                            viewModel.selectStory(story)
                        }
                    }
                )
            }
        }

        // --- Trending Now ---
        if (trending.isNotEmpty() && (selectedCategory == "All" || selectedCategory == "Trending")) {
            item {
                ContentRowSection(
                    title = "Trending Now",
                    subtitle = "Most watched AI narratives this week",
                    stories = trending,
                    onStoryClick = { viewModel.selectStory(it) }
                )
            }
        }

        // --- Popular Stories ---
        if (popular.isNotEmpty() && (selectedCategory == "All" || selectedCategory == "Popular" || selectedCategory == "Stories")) {
            item {
                ContentRowSection(
                    title = "Popular Stories",
                    subtitle = "High-rated continuous episodic story sagas",
                    stories = popular,
                    onStoryClick = { viewModel.selectStory(it) }
                )
            }
        }

        // --- AI Originals ---
        if (originals.isNotEmpty() && (selectedCategory == "All" || selectedCategory == "AI Originals")) {
            item {
                ContentRowSection(
                    title = "AI Originals",
                    subtitle = "Exclusively produced with cinematic AI video pipeline",
                    stories = originals,
                    onStoryClick = { viewModel.selectStory(it) }
                )
            }
        }

        // --- Latest Webseries ---
        if (webseries.isNotEmpty() && (selectedCategory == "All" || selectedCategory == "Webseries")) {
            item {
                ContentRowSection(
                    title = "Latest Webseries",
                    subtitle = "Multi-season high-octane serial dramas",
                    stories = webseries,
                    onStoryClick = { viewModel.selectStory(it) }
                )
            }
        }

        // --- Movies ---
        if (movies.isNotEmpty() && (selectedCategory == "All" || selectedCategory == "Movies")) {
            item {
                ContentRowSection(
                    title = "Movies",
                    subtitle = "Full-length AI feature films",
                    stories = movies,
                    onStoryClick = { viewModel.selectStory(it) }
                )
            }
        }

        // --- Dramas ---
        if (dramas.isNotEmpty() && (selectedCategory == "All" || selectedCategory == "Dramas")) {
            item {
                ContentRowSection(
                    title = "Dramas",
                    subtitle = "Emotional acting with realistic humanoid voices",
                    stories = dramas,
                    onStoryClick = { viewModel.selectStory(it) }
                )
            }
        }

        // --- Serials ---
        if (serials.isNotEmpty() && (selectedCategory == "All" || selectedCategory == "Serials")) {
            item {
                ContentRowSection(
                    title = "Serials",
                    subtitle = "Continuous long-form sagas with unlimited episodes",
                    stories = serials,
                    onStoryClick = { viewModel.selectStory(it) }
                )
            }
        }

        // --- Premium Highlight Banner ---
        item {
            PremiumPromoCard(
                isPremium = currentUser?.isPremium == true,
                onGetPremium = { viewModel.navigateTo(ScreenDestination.PREMIUM_PAYMENT) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun HomeTopBar(
    appName: String,
    isPremium: Boolean,
    onSearchClick: () -> Unit,
    onProfileClick: () -> Unit,
    onAdminClick: () -> Unit,
    onPremiumClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("home_top_bar"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // App Brand & Logo
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.clickable { }
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_launcher_logo),
                contentDescription = "Logo",
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .border(1.dp, AccentViolet, CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = appName,
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "CINEMATIC AI STREAMING",
                    color = AccentCyan,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        // Actions
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (!isPremium) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = AccentGold.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AccentGold),
                    modifier = Modifier.clickable(onClick = onPremiumClick)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.WorkspacePremium,
                            contentDescription = null,
                            tint = AccentGold,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "PREMIUM",
                            color = AccentGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
            }

            IconButton(onClick = onSearchClick, modifier = Modifier.testTag("top_search_button")) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = TextPrimary
                )
            }

            IconButton(onClick = onAdminClick, modifier = Modifier.testTag("top_admin_button")) {
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = "Admin Dashboard",
                    tint = AccentCyan
                )
            }

            IconButton(onClick = onProfileClick, modifier = Modifier.testTag("top_profile_button")) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(AccentViolet.copy(alpha = 0.25f))
                        .border(1.dp, AccentViolet, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isPremium) "VIP" else "U",
                        color = if (isPremium) AccentGold else AccentViolet,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun HeroBanner(
    story: StoryItem,
    isInMyList: Boolean,
    onWatchClick: () -> Unit,
    onToggleMyList: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(380.dp)
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .testTag("hero_banner_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceMidnight)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Hero Image
            Image(
                painter = painterResource(id = R.drawable.poster_the_last_city),
                contentDescription = story.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Cinematic Gradient Overlay
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                CanvasObsidian.copy(alpha = 0.6f),
                                CanvasObsidian.copy(alpha = 0.98f)
                            ),
                            startY = 150f
                        )
                    )
            )

            // Content on Hero
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
            ) {
                // AI Disclosure Badge
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = AccentViolet.copy(alpha = 0.9f)
                ) {
                    Text(
                        text = "AI-GENERATED ENTERTAINMENT • EPISODES 1-5 FREE",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.8.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = story.title,
                    color = TextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    lineHeight = 28.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = story.synopsis,
                    color = TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Metadata chips
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "⭐ ${story.rating}",
                        color = AccentGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "${story.episodesCount} Episodes",
                        color = AccentCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = story.genres.take(2).joinToString(" • "),
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onWatchClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = CanvasObsidian
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("hero_watch_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Watch Now",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onToggleMyList,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("hero_my_list_button")
                    ) {
                        Icon(
                            imageVector = if (isInMyList) Icons.Default.Check else Icons.Default.Add,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isInMyList) "In My List" else "+ My List",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ContentRowSection(
    title: String,
    subtitle: String,
    stories: List<StoryItem>,
    onStoryClick: (StoryItem) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 10.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = title,
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(stories) { story ->
                StoryCard(
                    story = story,
                    onClick = { onStoryClick(story) }
                )
            }
        }
    }
}

@Composable
fun ContinueWatchingSection(
    historyList: List<WatchProgress>,
    onItemClick: (WatchProgress) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 10.dp)) {
        Text(
            text = "Continue Watching",
            color = TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Text(
            text = "Jump straight back into your story",
            color = TextMuted,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(historyList) { item ->
                Card(
                    modifier = Modifier
                        .width(200.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onItemClick(item) }
                        .testTag("continue_card_${item.storyId}"),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(AccentViolet.copy(alpha = 0.5f), CanvasObsidian)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Resume",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }

                        // Progress indicator
                        LinearProgressIndicator(
                            progress = { item.progressPercentage },
                            modifier = Modifier.fillMaxWidth().height(4.dp),
                            color = AccentViolet,
                            trackColor = Color.DarkGray
                        )

                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = item.storyTitle,
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.episodeTitle,
                                color = AccentCyan,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PremiumPromoCard(
    isPremium: Boolean,
    onGetPremium: () -> Unit
) {
    if (isPremium) return

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("premium_promo_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, AccentGold.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = null,
                    tint = AccentGold,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Unlock the Full Story",
                    color = TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Episodes 1–5 are FREE for every story. Unlock Episode 6 onward with VIP all-access.",
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onGetPremium,
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentGold,
                    contentColor = CanvasObsidian
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("promo_get_premium_button")
            ) {
                Text(
                    text = "GET PREMIUM • FROM ₹199",
                    fontWeight = FontWeight.Black,
                    fontSize = 13.sp
                )
            }
        }
    }
}
