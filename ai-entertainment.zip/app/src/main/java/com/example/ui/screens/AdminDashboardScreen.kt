package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ai.StoryGenerationInput
import com.example.data.model.AppBrandingConfig
import com.example.data.model.ContentStatus
import com.example.data.model.ContentType
import com.example.ui.EntertainmentViewModel
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.AccentGreen
import com.example.ui.theme.AccentViolet
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CanvasObsidian
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceCardElevated
import com.example.ui.theme.SurfaceMidnight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AdminDashboardScreen(
    viewModel: EntertainmentViewModel,
    modifier: Modifier = Modifier
) {
    val stories by viewModel.allStories.collectAsState()
    val transactions by viewModel.allTransactions.collectAsState()
    val branding by viewModel.brandingConfig.collectAsState()
    val isGenerating by viewModel.isGeneratingAiStory.collectAsState()
    val lastPlan by viewModel.lastGeneratedPlan.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }

    // Analytics computation
    val totalRevenue = transactions.filter { it.status.name == "SUCCESS" }.sumOf { it.amountInr }
    val totalSubscribers = transactions.filter { it.status.name == "SUCCESS" }.map { it.userId }.distinct().size + 1
    val totalViews = 18450 + (stories.size * 320)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CanvasObsidian)
            .testTag("admin_dashboard_screen")
    ) {
        // --- Header ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "Admin Studio & Management",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "AI Production & Platform Controls",
                            color = AccentCyan,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // --- Tabs ---
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = SurfaceMidnight,
                contentColor = TextPrimary,
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = AccentViolet
                    )
                }
            ) {
                listOf(
                    Pair("Overview & Analytics", Icons.Default.Analytics),
                    Pair("AI Story Studio", Icons.Default.AutoAwesome),
                    Pair("Content Manager", Icons.Default.VideoLibrary),
                    Pair("Platform Settings", Icons.Default.Settings)
                ).forEachIndexed { idx, (title, icon) ->
                    Tab(
                        selected = selectedTab == idx,
                        onClick = { selectedTab = idx },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(icon, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = title,
                                    fontWeight = if (selectedTab == idx) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    )
                }
            }
        }

        // --- Tab 0: Overview & Analytics ---
        if (selectedTab == 0) {
            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Real-Time Platform Performance",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "Total Catalog Titles",
                            value = "${stories.size}",
                            color = AccentViolet,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "Total Views",
                            value = "$totalViews",
                            color = AccentCyan,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricCard(
                            title = "Active VIP Subs",
                            value = "$totalSubscribers",
                            color = AccentGold,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            title = "Gross Revenue",
                            value = "₹$totalRevenue",
                            color = AccentGreen,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "UPI Gateway Transactions",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    if (transactions.isEmpty()) {
                        Text("No recorded transactions yet.", color = TextMuted, fontSize = 12.sp)
                    } else {
                        transactions.take(5).forEach { txn ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(text = txn.orderId, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(text = "${txn.upiId} • ${txn.verificationNotes}", color = TextMuted, fontSize = 10.sp)
                                    }
                                    Text(
                                        text = "₹${txn.amountInr} (${txn.status.name})",
                                        color = if (txn.status.name == "SUCCESS") AccentGreen else AccentGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- Tab 1: AI Story Studio (Gemini Integration) ---
        if (selectedTab == 1) {
            item {
                AiStoryStudioSection(
                    isGenerating = isGenerating,
                    lastPlan = lastPlan,
                    onGenerate = { input -> viewModel.generateAiStory(input) }
                )
            }
        }

        // --- Tab 2: Content Manager ---
        if (selectedTab == 2) {
            item {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Stories & Series Catalog (${stories.size})",
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            items(stories) { story ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = story.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = "${story.contentType.name} • ${story.episodesCount} Episodes • Status: ${story.status.name}", color = AccentCyan, fontSize = 11.sp)
                        }

                        Button(
                            onClick = { viewModel.publishStory(story.id) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (story.status == ContentStatus.PUBLISHED) AccentGreen else SurfaceCardElevated
                            ),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (story.status == ContentStatus.PUBLISHED) "PUBLISHED" else "UNDER REVIEW",
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // --- Tab 3: Platform Settings ---
        if (selectedTab == 3) {
            item {
                PlatformSettingsSection(
                    config = branding,
                    onSave = { updated -> viewModel.updateBranding(updated) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = title, color = TextMuted, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, color = color, fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun AiStoryStudioSection(
    isGenerating: Boolean,
    lastPlan: com.example.data.ai.GeneratedStoryProductionPlan?,
    onGenerate: (StoryGenerationInput) -> Unit
) {
    var titleIdea by remember { mutableStateOf("The Quantum Rift: Odyssey 2099") }
    var genre by remember { mutableStateOf("Science Fiction") }
    var setting by remember { mutableStateOf("Underground Cyberpunk Metropolis Neo-Kalyan") }
    var charactersPrompt by remember { mutableStateOf("Jax Mercer (Cyber-Detective), Dr. Maya Lin (Quantum Biologist)") }
    var episodeCount by remember { mutableIntStateOf(10) }
    var tone by remember { mutableStateOf("Cinematic, Emotionally Intense, Fast-Paced") }
    var endingStyle by remember { mutableStateOf("Jaw-Dropping Revelation") }

    Column(modifier = Modifier.padding(16.dp)) {
        Text(
            text = "AI Story & Scriptwriter Studio",
            color = TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Powered by Gemini narrative intelligence and humanoid voice synthesis pipeline.",
            color = TextMuted,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = titleIdea,
            onValueChange = { titleIdea = it },
            label = { Text("Story / Series Idea") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = genre,
            onValueChange = { genre = it },
            label = { Text("Genre (e.g. Sci-Fi, Cyberpunk, Drama, Thriller)") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = setting,
            onValueChange = { setting = it },
            label = { Text("World & Setting Environment") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = charactersPrompt,
            onValueChange = { charactersPrompt = it },
            label = { Text("Lead Characters & Roles") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
        )

        Spacer(modifier = Modifier.height(14.dp))

        Button(
            onClick = {
                onGenerate(
                    StoryGenerationInput(
                        titleIdea = titleIdea,
                        genre = genre,
                        contentType = ContentType.STORY,
                        keyCharactersPrompt = charactersPrompt,
                        setting = setting,
                        numberOfEpisodes = episodeCount,
                        tone = tone,
                        endingStyle = endingStyle
                    )
                )
            },
            colors = ButtonDefaults.buttonColors(containerColor = AccentViolet),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("admin_generate_ai_story_button")
        ) {
            if (isGenerating) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generating with Gemini Narrative Engine...")
            } else {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate Multi-Episode Series with AI")
            }
        }

        if (lastPlan != null) {
            Spacer(modifier = Modifier.height(20.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceMidnight),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, AccentCyan.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Generated Production Plan Ready",
                        color = AccentCyan,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = lastPlan.logline, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(text = "Long-Story Continuity Database:", color = AccentGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(text = lastPlan.continuityNotes, color = TextSecondary, fontSize = 11.sp)

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Generated Episodes: ${lastPlan.episodeBreakdowns.size}", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    lastPlan.episodeBreakdowns.take(3).forEach { ep ->
                        Text(text = "• ${ep.title}: ${ep.summary}", color = TextMuted, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun PlatformSettingsSection(
    config: AppBrandingConfig,
    onSave: (AppBrandingConfig) -> Unit
) {
    var appName by remember { mutableStateOf(config.appName) }
    var primaryUpi by remember { mutableStateOf(config.primaryUpiId) }
    var secondaryUpi by remember { mutableStateOf(config.secondaryUpiId) }
    var freeLimit by remember { mutableIntStateOf(config.freeEpisodesLimit) }
    var monthlyPrice by remember { mutableIntStateOf(config.monthlyPriceInr) }
    var savedMessage by remember { mutableStateOf(false) }

    Column(modifier = Modifier.padding(16.dp)) {
        Text(
            text = "Branding & Payment Gateway Configuration",
            color = TextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Configure app name, UPI settlement IDs, and monetization tiers.",
            color = TextMuted,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = appName,
            onValueChange = { appName = it },
            label = { Text("Application Brand Name") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = primaryUpi,
            onValueChange = { primaryUpi = it },
            label = { Text("Primary UPI ID") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = secondaryUpi,
            onValueChange = { secondaryUpi = it },
            label = { Text("Secondary UPI ID") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = freeLimit.toString(),
            onValueChange = { freeLimit = it.toIntOrNull() ?: 5 },
            label = { Text("Free Episodes per Story (Default 5)") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = monthlyPrice.toString(),
            onValueChange = { monthlyPrice = it.toIntOrNull() ?: 199 },
            label = { Text("Monthly Premium Price (INR)") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary)
        )

        if (savedMessage) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "✓ Configuration saved and applied successfully!",
                color = AccentGreen,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        Button(
            onClick = {
                onSave(
                    config.copy(
                        appName = appName,
                        primaryUpiId = primaryUpi,
                        secondaryUpiId = secondaryUpi,
                        freeEpisodesLimit = freeLimit,
                        monthlyPriceInr = monthlyPrice
                    )
                )
                savedMessage = true
            },
            colors = ButtonDefaults.buttonColors(containerColor = AccentCyan, contentColor = CanvasObsidian),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Save & Apply Settings", fontWeight = FontWeight.Bold)
        }
    }
}
