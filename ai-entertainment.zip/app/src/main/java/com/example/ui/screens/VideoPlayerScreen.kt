package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.admob.AdMobBanner
import com.example.data.admob.AdMobManager
import com.example.ui.EntertainmentViewModel
import com.example.ui.ScreenDestination
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentGold
import com.example.ui.theme.AccentViolet
import com.example.ui.theme.CanvasObsidian
import com.example.ui.theme.SurfaceCard
import com.example.ui.theme.SurfaceMidnight
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

@Composable
fun VideoPlayerScreen(
    viewModel: EntertainmentViewModel,
    modifier: Modifier = Modifier
) {
    val story = viewModel.playingStory.collectAsState().value
    val episode = viewModel.playingEpisode.collectAsState().value
    val savedPos = viewModel.savedPlaybackPosition.collectAsState().value
    val episodes = viewModel.selectedStoryEpisodes.collectAsState().value
    val currentUser = viewModel.currentUser.collectAsState().value
    val isPremium = currentUser?.isPremium == true

    if (story == null || episode == null) {
        Box(
            modifier = modifier.fillMaxSize().background(CanvasObsidian),
            contentAlignment = Alignment.Center
        ) {
            Text("No media loaded", color = TextSecondary)
        }
        return
    }

    // Playback state
    var isPlaying by remember { mutableStateOf(true) }
    var currentSeconds by remember { mutableLongStateOf(savedPos) }
    val totalSeconds = remember(episode) { (episode.durationMinutes * 60).toLong().coerceAtLeast(120L) }
    var controlsVisible by remember { mutableStateOf(true) }

    // Settings / Dialog states
    var showQualityDialog by remember { mutableStateOf(false) }
    var selectedQuality by remember { mutableStateOf("1080p AI-Upscaled") }
    var showSubtitlesDialog by remember { mutableStateOf(false) }
    var selectedSubtitle by remember { mutableStateOf("English") }
    var showSpeedDialog by remember { mutableStateOf(false) }
    var selectedSpeed by remember { mutableFloatStateOf(1.0f) }
    var showEpisodeSelector by remember { mutableStateOf(false) }

    // Auto next countdown state
    var showNextCountdown by remember { mutableStateOf(false) }
    var countdownSeconds by remember { mutableIntStateOf(5) }

    // Playback loop simulation: increments timer, saves progress
    LaunchedEffect(isPlaying, selectedSpeed) {
        while (isPlaying) {
            delay((1000 / selectedSpeed).toLong())
            if (currentSeconds < totalSeconds) {
                currentSeconds += 1
                // Save progress every 5 seconds
                if (currentSeconds % 5 == 0L) {
                    viewModel.onEpisodePlaybackProgress(currentSeconds, totalSeconds)
                }

                // Trigger next episode prompt near end
                if (totalSeconds - currentSeconds <= 10 && !showNextCountdown) {
                    showNextCountdown = true
                }
            } else {
                isPlaying = false
                viewModel.onEpisodePlaybackProgress(totalSeconds, totalSeconds)
                showNextCountdown = true
            }
        }
    }

    // Countdown loop for auto next
    LaunchedEffect(showNextCountdown) {
        if (showNextCountdown) {
            countdownSeconds = 5
            while (countdownSeconds > 0) {
                delay(1000)
                countdownSeconds -= 1
            }
            showNextCountdown = false
            viewModel.playNextEpisode()
        }
    }

    // Hide controls after 4 seconds of inactivity
    LaunchedEffect(controlsVisible, isPlaying) {
        if (controlsVisible && isPlaying) {
            delay(4000)
            controlsVisible = false
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                controlsVisible = !controlsVisible
            }
            .testTag("video_player_container")
    ) {
        // --- Video Render Area ---
        if (story.id == "story_last_city") {
            Image(
                painter = painterResource(id = R.drawable.poster_the_last_city),
                contentDescription = episode.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(SurfaceMidnight, Color.Black)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = AccentCyan.copy(alpha = 0.5f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Streaming AI Generated Video",
                        color = AccentCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "${selectedQuality} • ${selectedSpeed}x",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // Subtitle Overlay (if active)
        if (selectedSubtitle != "Off" && isPlaying) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 90.dp)
                    .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = getSimulatedSubtitle(currentSeconds, selectedSubtitle),
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        // --- Controls Overlay ---
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.55f))
            ) {
                // Top Player Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                        .align(Alignment.TopStart),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = {
                                viewModel.onEpisodePlaybackProgress(currentSeconds, totalSeconds)
                                viewModel.navigateBack()
                            },
                            modifier = Modifier.testTag("player_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Column {
                            Text(
                                text = story.title,
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = episode.title,
                                color = AccentCyan,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Quality button
                        IconButton(onClick = { showQualityDialog = true }) {
                            Icon(
                                imageVector = Icons.Default.HighQuality,
                                contentDescription = "Quality",
                                tint = Color.White
                            )
                        }

                        // Subtitles button
                        IconButton(onClick = { showSubtitlesDialog = true }) {
                            Icon(
                                imageVector = Icons.Default.ClosedCaption,
                                contentDescription = "Subtitles",
                                tint = if (selectedSubtitle != "Off") AccentCyan else Color.White
                            )
                        }

                        // Playback Speed button
                        IconButton(onClick = { showSpeedDialog = true }) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Speed",
                                tint = Color.White
                            )
                        }
                    }
                }

                // Center Play / Pause / Rewind / Fast-forward buttons
                Row(
                    modifier = Modifier.align(Alignment.Center),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(32.dp)
                ) {
                    // Rewind 10s
                    IconButton(
                        onClick = { currentSeconds = (currentSeconds - 10).coerceAtLeast(0L) },
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            .testTag("player_rewind_10")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastRewind,
                            contentDescription = "Rewind 10s",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    // Play / Pause
                    IconButton(
                        onClick = { isPlaying = !isPlaying },
                        modifier = Modifier
                            .size(64.dp)
                            .background(AccentViolet, CircleShape)
                            .testTag("player_play_pause_button")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    // Fast Forward 10s
                    IconButton(
                        onClick = { currentSeconds = (currentSeconds + 10).coerceAtMost(totalSeconds) },
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            .testTag("player_forward_10")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FastForward,
                            contentDescription = "Forward 10s",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // Bottom Timeline and Actions
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    // Time labels & Next Episode
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${formatTime(currentSeconds)} / ${formatTime(totalSeconds)}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = { showEpisodeSelector = true }) {
                                Text(
                                    text = "Episodes (${episode.episodeNumber}/${episodes.size})",
                                    color = AccentCyan,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            IconButton(onClick = { viewModel.playNextEpisode() }) {
                                Icon(
                                    imageVector = Icons.Default.SkipNext,
                                    contentDescription = "Next Episode",
                                    tint = Color.White
                                )
                            }
                        }
                    }

                    // Scrubber
                    Slider(
                        value = if (totalSeconds > 0) currentSeconds.toFloat() / totalSeconds.toFloat() else 0f,
                        onValueChange = { frac ->
                            currentSeconds = (frac * totalSeconds).toLong()
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = AccentViolet,
                            activeTrackColor = AccentViolet,
                            inactiveTrackColor = Color.Gray.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("player_slider")
                    )
                }
            }
        }

        // --- Next Episode Auto-Play Banner ---
        if (showNextCountdown) {
            Card(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(end = 16.dp, bottom = 80.dp)
                    .testTag("auto_next_banner"),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceMidnight),
                border = androidx.compose.foundation.BorderStroke(1.dp, AccentViolet)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Next Episode in $countdownSeconds s",
                            color = AccentCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Playing next continuous episode",
                            color = TextPrimary,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Button(
                        onClick = {
                            showNextCountdown = false
                            viewModel.playNextEpisode()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentViolet),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("Play Now", fontSize = 11.sp)
                    }
                }
            }
        }
    }

    // --- Quality Dialog ---
    if (showQualityDialog) {
        AlertDialog(
            onDismissRequest = { showQualityDialog = false },
            title = { Text("Stream Quality", color = TextPrimary) },
            text = {
                Column {
                    listOf("1080p AI-Upscaled (Best)", "720p HD", "480p SD", "Auto (Data Saver)").forEach { q ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedQuality = q
                                    showQualityDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = q,
                                color = if (selectedQuality == q) AccentViolet else TextPrimary,
                                fontWeight = if (selectedQuality == q) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showQualityDialog = false }) {
                    Text("Close", color = AccentViolet)
                }
            },
            containerColor = SurfaceCard
        )
    }

    // --- Subtitles Dialog ---
    if (showSubtitlesDialog) {
        AlertDialog(
            onDismissRequest = { showSubtitlesDialog = false },
            title = { Text("Subtitles", color = TextPrimary) },
            text = {
                Column {
                    listOf("English", "Hindi", "Spanish", "Off").forEach { sub ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedSubtitle = sub
                                    showSubtitlesDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = sub,
                                color = if (selectedSubtitle == sub) AccentCyan else TextPrimary,
                                fontWeight = if (selectedSubtitle == sub) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSubtitlesDialog = false }) {
                    Text("Close", color = AccentCyan)
                }
            },
            containerColor = SurfaceCard
        )
    }

    // --- Speed Dialog ---
    if (showSpeedDialog) {
        AlertDialog(
            onDismissRequest = { showSpeedDialog = false },
            title = { Text("Playback Speed", color = TextPrimary) },
            text = {
                Column {
                    listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedSpeed = speed
                                    showSpeedDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${speed}x ${if (speed == 1.0f) "(Normal)" else ""}",
                                color = if (selectedSpeed == speed) AccentGold else TextPrimary,
                                fontWeight = if (selectedSpeed == speed) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showSpeedDialog = false }) {
                    Text("Close", color = AccentGold)
                }
            },
            containerColor = SurfaceCard
        )
    }

    // --- Episode Drawer / Selector Dialog ---
    if (showEpisodeSelector) {
        AlertDialog(
            onDismissRequest = { showEpisodeSelector = false },
            title = { Text("Select Episode", color = TextPrimary) },
            text = {
                LazyColumn(modifier = Modifier.height(280.dp)) {
                    items(episodes) { ep ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showEpisodeSelector = false
                                    viewModel.playEpisode(story, ep)
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = ep.title,
                                    color = if (ep.id == episode.id) AccentViolet else TextPrimary,
                                    fontWeight = if (ep.id == episode.id) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "${ep.durationMinutes} mins",
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            }
                            if (ep.isFree) {
                                Text("FREE", color = AccentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            } else {
                                Icon(
                                    imageVector = Icons.Default.WorkspacePremium,
                                    contentDescription = "Premium",
                                    tint = AccentGold,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                AdMobBanner(
                    modifier = Modifier.fillMaxWidth(),
                    isPremiumUser = isPremium
                )
            },
            confirmButton = {
                TextButton(onClick = { showEpisodeSelector = false }) {
                    Text("Close", color = TextPrimary)
                }
            },
            containerColor = SurfaceCard
        )
    }
}

private fun formatTime(seconds: Long): String {
    val mins = seconds / 60
    val secs = seconds % 60
    return "%02d:%02d".format(mins, secs)
}

private fun getSimulatedSubtitle(currentSec: Long, lang: String): String {
    val step = (currentSec / 4) % 4
    return when (lang) {
        "Hindi" -> when (step.toInt()) {
            0 -> "हम अब पीछे नहीं हट सकते।"
            1 -> "सिग्नल मुख्य सर्वर से आ रहा है।"
            2 -> "सावधानी से आगे बढ़ो, एआई सक्रिय है।"
            else -> "यह मानवता का अंतिम अवसर है।"
        }
        "Spanish" -> when (step.toInt()) {
            0 -> "No podemos dar marcha atrás ahora."
            1 -> "La señal proviene del servidor central."
            2 -> "Avanza con cuidado, la IA está activa."
            else -> "Esta es la última oportunidad de la humanidad."
        }
        else -> when (step.toInt()) {
            0 -> "Jax: We can't turn back now."
            1 -> "Elena: The anomaly is originating from Sector 7."
            2 -> "Voice: Proceed with caution, consciousness detected."
            else -> "Jax: Humanity's future begins here."
        }
    }
}
