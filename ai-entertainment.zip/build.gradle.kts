// Top-level build file where you can add configuration options common to all sub-projects/modules.

// Auto-decode debug.keystore from debug.keystore.base64 if missing (essential for GitHub Actions CI builds)
val debugKeystoreFile = file("debug.keystore")
val debugKeystoreBase64File = file("debug.keystore.base64")
if (!debugKeystoreFile.exists() && debugKeystoreBase64File.exists()) {
  try {
    val decoded = java.util.Base64.getDecoder().decode(debugKeystoreBase64File.readText().trim())
    debugKeystoreFile.writeBytes(decoded)
  } catch (e: Exception) {
    println("Note: Could not decode debug.keystore from base64: ${e.message}")
  }
}
// Fallback upload key for CI release builds when external keystore is not mounted
val uploadKeyFile = file("my-upload-key.jks")
if (!uploadKeyFile.exists() && debugKeystoreFile.exists()) {
  try {
    uploadKeyFile.writeBytes(debugKeystoreFile.readBytes())
  } catch (_: Exception) {}
}

plugins {
  alias(libs.plugins.android.application) apply false
  alias(libs.plugins.kotlin.compose) apply false
  alias(libs.plugins.google.devtools.ksp) apply false
  alias(libs.plugins.roborazzi) apply false
  alias(libs.plugins.secrets) apply false
  alias(libs.plugins.google.services) apply false
}
